<?php 
function ip_blacklist_block() 
{
    $ip_list = get_option('ip_blacklist', array());
    $ip_address = $_SERVER['REMOTE_ADDR'];
    if (in_array($ip_address, $ip_list)) {
        wp_die('Votre adresse IP a été bloquée.');
    }
}
?>