<?php
function ip_blacklist_admin_menu() {
    // Add menu page
    add_menu_page(
        ''.BLACKLISTED_IP_NAME.'', // Le nom de la page dans le menu
        ''.BLACKLISTED_IP_NAME.'', // Le nom de la page
        'manage_options', // Le niveau de permission nécessaire pour voir la page
        'ip-blacklist', // Le slug de la page
        'ip_blacklist_page', // La fonction qui affiche la page
        'dashicons-podio' // L'icône à utiliser
    );
}
?>