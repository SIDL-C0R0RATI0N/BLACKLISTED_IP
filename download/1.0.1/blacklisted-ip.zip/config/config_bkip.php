<?php
/* CONFIGURATION DE BASE DU PLUGIN */
define('BLACKLISTED_IP_NAME','BLACKLISTED IP'); // Nom du plugin
define('BLACKLISTED_IP_NAME_2','blacklisted IP'); // Nom du plugin
define('BLACKLISTED_IP_VERSION','1.0.1'); // Version du plugin
define('BLACKLISTED_IP_NEWS_VERSION','1.0.1'); // Nouvelle version du plugin
define('BLACKLISTED_IP_VERSION_TYPE','STABLE'); // Type de version du plugin
define('BLACKLISTED_IP_SLUG', 'blacklisted-ip'); // Slug du plugin
define('BLACKLISTED_IP_PLUGIN_DOMAIN','blacklisted-ip'); // Teste de domaine du plugin
define('BLACKLISTED_IP_PLUGIN_PACKAGE_NAME','ip_blacklist'); // Nom de package du plugin
define('ADMIN_YOUR_IP', 'VOTRE IP : <abbr title="Votre adresse IP est : '.$_SERVER['REMOTE_ADDR'].'" class="initialism">'.$_SERVER['REMOTE_ADDR'].'</abbr>');
/* DEPENDANCE (IPINFO) */
define('BLACKLISTED_IP_URL_IPINFO_PART_1', 'http://ipinfo.io/');
define('BLACKLISTED_IP_URL_IPINFO_PART_2', '/json');
/* DEPENDANCE (GITHUB) */
define('BLACKLISTED_IP_GITHUB_USERNAME', 'SIDL-C0R0RATI0N');
define('BLACKLISTED_IP_AUTHOR', 'SIDL CORPORATI0N');
define('BLACKLISTED_IP_GITHUB_REPO', 'BLACKLISTED_IP');
define('BLACKLISTED_IP_GITHUB_API_URL', 'https://api.github.com/repos/'.BLACKLISTED_IP_GITHUB_USERNAME.'/'.BLACKLISTED_IP_GITHUB_REPO);
define('BLACKLISTED_IP_URL_CHANGELOG','https://github.com/'.BLACKLISTED_IP_GITHUB_USERNAME.'/'.BLACKLISTED_IP_GITHUB_REPO.'/blob/main/CHANGELOG.md#version-4001--22102022');
/* VERSION WORDPRESS */
define('BLACKLISTED_IP_WP_VERSION', get_bloginfo('version'));
define('BLACKLISTED_IP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('BLACKLISTED_IP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('BLACKLISTED_IP_PLUGIN_BASENAME', plugin_basename(__FILE__));
/* PREREQUIS */
define('PR_PHP_VERSION', '7.4');
define('RL_WP_VERSION', '4.0');
define('TUT_WP_VERSION', get_bloginfo('version'));
define('ST_PLUGIN_VERSION', BLACKLISTED_IP_VERSION);
define('BUILD_PLUGIN_VERSION', BLACKLISTED_IP_VERSION);
define('LICENCE_PLUGIN_TYPE', 'GPL2');
/* AUTRES CONFIGURATION */
define('BLACKLISTED_IP_SUPPORT_LINK','');
define('BLACKLISTED_IP_RELEASES_LINK','');
define('BLACKLISTED_IP','Bienvenue sur la nouvelles version (<i>'.BLACKLISTED_IP_VERSION.'</i>) du plugin <b>'.BLACKLISTED_IP_NAME.'</b>. Dans cette nouvelle version, nous avons apporter des nouveautés, dont nous avons supprimer la fonctionnalité avec <b>CloudFlare</b>. Dont vous pouvez l\'utiliser à votre guise.');
define('BLACKLISTED_IP_DESCRIP','Bienvenue sur la nouvelle version du Plugin <b>'.BLACKLISTED_IP_NAME.'</b>.<br/> Dans cette nouvelle version, nous avons faite quelques changement. N\'hésitez pas à voir notre changelog pour la version <a href="'.BLACKLISTED_IP_URL_CHANGELOG.'" target="_blank">'.BLACKLISTED_IP_VERSION.'</a>.');

define('BTN_TXT_BLACKLISTED','Bannir une adresse IP');
define('BTN_TXT_CHANGELOG','Journale des mises à jours');
define('BTN_TXT_UPDATE','Mises à jours du plugin');
define('BTN_TXT_ABOUTS','À propos.');
/* VERSION FRANCAISE DU PLUGIN */
if((substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2)) == "fr")
{
    /* MENU DU PLUGIN */
    define('TXT_MENU_TABS_1','Présentation');
    define('TXT_MENU_TABS_2','Bannir une IP');
    define('TXT_MENU_TABS_3','Journal des mises à jour');
    define('TXT_MENU_TABS_4','Mise à jour du plugin');
    define('TXT_MENU_TABS_5','À propos');
    /* BOUTONS */
    define('TXT_BUTTON_1','NOTRE SITE INTERNET');
    define('TXT_BUTTON_2','CONTACT SUPPORT');
    define('TXT_BUTTON_3','Télécharger la mise à jour');
    define('TXT_BUTTON_4','Voir le journal de mise à jour');
    define('TXT_BUTTON_5','<abbr title="Vous allez êtres rediriger vers Google Maps" class="initialism">Voir la localisation</abbr>');
    define('TXT_BUTTON_6','Ne plus bannir');
    define('TXT_BUTTON_7','Ajouter à la liste noire');
    define('TXT_BUTTON_8','Télécharger la dernière version');
    define('TXT_BUTTON_9','Installer maintenant');
    /* TEXTE DES TITRE DES PAGES */
    define('TITLE_PAGE_TABS_1','BIENVENUE SUR LE PLUGIN '.BLACKLISTED_IP_NAME.'.');
    define('TITLE_PAGE_TABS_2','Bannir / Débannir une <b>adresse IP</b>.');
    define('TITLE_PAGE_TABS_3','Journale des dernières mises à jours.');
    define('TITLE_PAGE_TABS_4','Mise à jour du plugin.');
    define('TITLE_PAGE_TABS_5','À propos, Licence & Informations sur l\'éditeur du plugin.');
    /* TABS = BANNIR UNE IP */
    define('TABS_2_ALERT_1','<div class="notice notice-warning settings-error is-dismissible"><p>L\'adresse IP a été ajoutée à la liste noire.</p></div>');
    define('TABS_2_ALERT_2','<div class="notice notice-success settings-error is-dismissible"><p>L\'adresse IP a été supprimée de la liste noire.</p></div>');
    define('TABS_2_TEXT_1','Veuillez saisir une adresse ip...');
    define('TABS_2_TEXT_2','Adresse IP');
    define('TABS_2_TEXT_3','Pays');
    define('TABS_2_TEXT_4','Ville');
    define('TABS_2_TEXT_5','Region');
    define('TABS_2_TEXT_6','Fuseaux horaires');
    define('TABS_2_TEXT_7','Localisation');
    define('TABS_2_TEXT_8','Action');
    /* TABS = MISE A JOUR */
    define('TABS_4_ALERT_1','Le plugin à détecter une nouvelle mise à jour. Merci de bien vouloir mettre à jour le plugin, car ça peut apporter des améliorations, des corrections ou encore des ajouts de nouvelles fonctionnalités.');
    define('TABS_4_ALERT_2_TITLE','INFORMATION SUR LA MISE À JOUR ET L\'INSTALLATION.');
    define('TABS_4_ALERT_2_CONTENT','Pour télécharger la mise à jour, vous avez juste à cliquez sur le bouton « <b>'.TXT_BUTTON_3.'</b> », et pour installer la mise à jour, veuillez vous rendre à la page « <b><a href="plugin-install.php?tab=upload" target="_parent">Extensions => Ajouter</a></b> » et à déplacer le fichier « <b><abbr title="Nom du fichier du plugin." class="initialism">blacklisted-ip.zip</abbr></b> » et cliquez sur le bouton « <b>Installer maintenant</b> ».');
    define('TABS_4_ALERT_3','Le plugin est actuellement à jour...');
    define('TABS_4_ALERT_4','Le système de mise à jour à détecter des problèmes lié avec votre version. Pour toutes sécurité, merci de bien vouloir télécharger la dernière version en cliquant sur le bouton ci-dessous...');
    define('TABS_4_TEXT_1','&nbsp;À UNE NOUVELLE MISE À JOUR DISPONIBLE...');
    define('TABS_4_TEXT_2','Version actuelle : ');
    define('TABS_4_TEXT_3','Nouvelles version : ');
    define('TABS_4_TEXT_4','ID de la mise à jour : ');
    define('TABS_4_TEXT_5','Mise à jour publié : ');
    define('TABS_4_TEXT_6','&nbsp;EST ACTUELLEMENT À JOUR...');
    define('TABS_4_TEXT_7','Version disponible : ');
    define('TABS_4_TEXT_8','ID de la dernière mise à jour : ');
    define('TABS_4_TEXT_9','Date de publication de la dernière mise à jour : ');
    define('TABS_4_TEXT_10','NOTE DE LA MISE À JOURS');
    define('TABS_4_TEXT_11','NOTE DE LA DERNIÈRE MISE À JOURS');
    define('TABS_4_TEXT_12','&nbsp;N\'ARRIVE PAS À DETECTER DE MISE À JOUR...');
    define('TABS_4_TEXT_13','<b style="color:red;">⚠ ATTENTION : </b>Le système de mise à jour n\'arrive pas à trouver de nouvelle mise à jour du plugin, car soient votre version à était modifier par une personne malveillante, et peut ainsi récupérer plusieurs données via notre code, ou, le plugin ne peut plus trouver de mise à jour, car les liens on était changer, ou soient, la version que vous avez est une version obsolète.');
    define('TABS_4_TEXT_14','Sachez que vous pouvez tout de même télécharger la dernière version via le bouton ci-dessous, en cas de problème.<br/><br/>Sachez que même avec le problème de mise à jour, votre version de plugin fonctionne mes vous ne pourrez pas obtenir de correctif aux problème, ou encore d\'ajouts ou d\'amélioration du plugin car vous exécuté une version <b>Annulée</b> ou une version <b>Obsolète</b>.<br/><br/>Pour télécharger le dernière version, cliquez sur le bouton « <b>'.TXT_BUTTON_8.'</b> » et pour l\'installer, cliquez sur le bouton « <b>Installer maintenant</b> ».');
    define('TABS_4_TEXT_15','<b>VERSION : </b>'.BLACKLISTED_IP_VERSION);
    define('TABS_4_TEXT_16','<b>LICENCE : </b> GPL2');
    define('TABS_4_TEXT_17','LICENCE :');
    define('TABS_4_TEXT_18','<abbr title="Version du plugin installer & que vous utilisez." class="initialism">VERSION : '.BLACKLISTED_IP_VERSION.'</abbr>');
    /* TABS = PRESENTATION (DOCUMENTATION) */
    define('TABS_1_TITLE_1','<b>MENU</b>');
    define('TABS_1_TITLE_2','Documentation du plugin WordPress '.BLACKLISTED_IP_NAME_2);
    define('TABS_1_MENU_1','Introduction & Prérequis');
    define('TABS_1_MENU_2','Installation');
    define('TABS_1_MENU_3','Utilisation');
    define('TABS_1_MENU_4','Avertissement');
    define('TABS_1_SUBTITLE_1','Introduction & Prérequis');
    define('TABS_1_SUBTITLE_2','Installation');
    define('TABS_1_SUBTITLE_3','Utilisation');
    define('TABS_1_SUBTITLE_4','Avertissement');
    define('TABS_1_TXT_1','Bienvenue dans la documentation du plugin '.BLACKLISTED_IP_NAME_2.'. Cette documentation est destinée aux utilisateurs qui souhaitent utiliser le plugin pour blacklister des utilisateurs. Ci-dessous, retrouvez ainsi les pré-requis du plugin.<br><br>Le plugin '.BLACKLISTED_IP_NAME_2.' vous permet de gérer une liste noire des adresses IP qui ne sont pas autorisées à accéder à votre site WordPress.');
    define('TABS_1_TXT_2','<ol><li>Téléchargez le plugin <code>Blacklisted IP</code> à partir du dépôt Github puis télécharger <code>blacklisted-ip</code> dans le dossier <code>/wp-content/plugins/</code>.</li><li>Activez le plugin dans votre tableau de bord WordPress.</li><li>Accéder directement au plugin depuis le menu latéral gauche qui porte le nom <code>Blacklisted IP</code>.</li></ol>');
    define('TABS_1_TXT_3','Une fois le plugin activé, vous pouvez accéder à la page <code>Blacklisted IP</code> en dessous de "Réglages" de votre tableau de bord WordPress. Cette page vous permet d\'ajouter ou de supprimer des adresses IP de la liste noire et de voir la liste des adresses IP bannies.');
    define('TABS_1_TXT_4','L\'utilisation de ce plugin peut bloquer l\'accès à votre site pour les adresses IP bannies. Assurez-vous de ne pas bannir votre propre adresse IP et de sauvegarder la liste des adresses IP autorisées avant d\'ajouter des adresses à la liste noire.');
    define('TABS_1_H_TABLE_1','PHP Requis'); //Requires PHP
    define('TABS_1_H_TABLE_2','Nécessite au moins'); //Requires at least
    define('TABS_1_H_TABLE_3','Testé jusqu\'à'); //Tested up to
    define('TABS_1_H_TABLE_4','Version stable'); //Stable tag
    define('TABS_1_H_TABLE_5','Version du plugin'); //Version
    define('TABS_1_H_TABLE_6','Licence'); //License
    define('TABS_1_H_TABLE_7','URL de la licence'); //URI License
    define('TABS_1_C_TABLE_1', PR_PHP_VERSION);
    define('TABS_1_C_TABLE_2', RL_WP_VERSION);
    define('TABS_1_C_TABLE_3', TUT_WP_VERSION);
    define('TABS_1_C_TABLE_4', ST_PLUGIN_VERSION);
    define('TABS_1_C_TABLE_5', BUILD_PLUGIN_VERSION);
    define('TABS_1_C_TABLE_6', LICENCE_PLUGIN_TYPE);
    define('TABS_1_BUTTON_1','En savoir + ('.LICENCE_PLUGIN_TYPE.')');
    /* AUTRES ALERTE */
    define('PLUGIN_ALERT_PHP','<div class="notice notice-warning settings-error"><h3 class="text-warning">IMPORTANT ! - Votre version de PHP n\'est actuellement pas prise en charge !</h3><p>Votre version PHP (<b>'.phpversion().'</b>) n\'est actuellement pas supporter par le plugin '.BLACKLISTED_IP_NAME_2.', pour le moment. Le plugin support jusqu\'à le version PHP '.PR_PHP_VERSION.'.<br></p></div>');
    define('PLUGIN_ALERT_UPDATE','<div class="notice notice-success"><h3>Nouvelle mise à jour disponible !</h3><p>Une nouvelle mise à jour est disponible, rendez-vous sur la <a href="admin.php?page=ip-blacklist&tab=tabs4">page de mise à jour</a> pour la télécharger et l\'installer ou contactez le support pour faire l\'installation.</p></div>');
}
/* VERSION ANGLAISE DU PLUGIN */
elseif((substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2)) == "en")
{
    /* MENU DU PLUGIN */
    define('TXT_MENU_TABS_1','Presentation');
    define('TXT_MENU_TABS_2','Ban an IP');
    define('TXT_MENU_TABS_3','Journal des mises à jour');
    define('TXT_MENU_TABS_4','Update log');
    define('TXT_MENU_TABS_5','In regards to');
    /* BOUTONS */
    define('TXT_BUTTON_1','OUR WEBSITE');
    define('TXT_BUTTON_2','SUPPORT CONTACT');
    define('TXT_BUTTON_3','Download update');
    define('TXT_BUTTON_4','View update log');
    define('TXT_BUTTON_5','<abbr title="You will be redirected to Google Maps" class="initialism">See location</abbr>');
    define('TXT_BUTTON_6','Do not ban again');
    define('TXT_BUTTON_7','Add to blacklist');
    define('TXT_BUTTON_8','Download the latest version');
    define('TXT_BUTTON_9','Install now');
    /* TEXTE DES TITRE DES PAGES */
    define('TITLE_PAGE_TABS_1','WELCOME TO THE PLUGIN '.BLACKLISTED_IP_NAME.'.');
    define('TITLE_PAGE_TABS_2','Ban / Unban an <b>IP address</b>.');
    define('TITLE_PAGE_TABS_3','Log of the latest updates.');
    define('TITLE_PAGE_TABS_4','Plugin update.');
    define('TITLE_PAGE_TABS_5','About, License & Plugin Publisher Information.');
    /* TABS = BANNIR UNE IP */
    define('TABS_2_ALERT_1','<div class="notice notice-warning settings-error is-dismissible"><p>The IP address has been added to the blacklist.</p></div>');
    define('TABS_2_ALERT_2','<div class="notice notice-success settings-error is-dismissible"><p>The IP address has been removed from the blacklist.</p></div>');
    define('TABS_2_TEXT_1','Please enter an ip address...');
    define('TABS_2_TEXT_2','IP adress');
    define('TABS_2_TEXT_3','Country');
    define('TABS_2_TEXT_4','City');
    define('TABS_2_TEXT_5','Region');
    define('TABS_2_TEXT_6','Time zones');
    define('TABS_2_TEXT_7','Location');
    define('TABS_2_TEXT_8','Action');
    /* TABS = MISE A JOUR */
    define('TABS_4_ALERT_1','The plugin detected a new update. Thank you for agreeing to update the plugin, as it may bring improvements, corrections or additions of new features.');
    define('TABS_4_ALERT_2_TITLE','UPDATE AND INSTALLATION INFORMATION.');
    define('TABS_4_ALERT_2_CONTENT','To download the update, you just have to click on the button “<b>'.TXT_BUTTON_3.'</b>”, and to install the update, please go to the page “<b><a href="plugin-install.php?tab=upload" target="_parent">Extensions => Add</a></b>" and move the file "<b><abbr title="File name of plug-in." class="initialism">blacklisted-ip.zip</abbr></b>" and click the "<b>Install Now</b>" button.');
    define('TABS_4_ALERT_3','The plugin is currently up to date...');
    define('TABS_4_ALERT_4','The system updates to detect issues related to your version. For all security, please download the latest version by clicking on the button below...');
    define('TABS_4_TEXT_1','&nbsp;TO A NEW UPDATE AVAILABLE...');
    define('TABS_4_TEXT_2','Current version : ');
    define('TABS_4_TEXT_3','New releases : ');
    define('TABS_4_TEXT_4','Update ID : ');
    define('TABS_4_TEXT_5','Update released : ');
    define('TABS_4_TEXT_6','&nbsp;IS CURRENTLY UPDATED...');
    define('TABS_4_TEXT_7','Version available : ');
    define('TABS_4_TEXT_8','Last Update ID : ');
    define('TABS_4_TEXT_9','Release date of the last update : ');
    define('TABS_4_TEXT_10','UPDATE NOTE');
    define('TABS_4_TEXT_11','LAST UPDATE RATING');
    define('TABS_4_TEXT_12','&nbsp;CANNOT DETECT UPDATE...');
    define('TABS_4_TEXT_13','<b style="color:red;">⚠ WARNING: </b> The update system cannot find a new plugin update, because your version has been modified by a malicious person, and can thus recover several data via our code, or, the plugin can no longer find an update, because the links have changed, or, the version you have is an obsolete version.');
    define('TABS_4_TEXT_14','Note that you can still download the latest version via the button below, in case of problems.<br/><br/>Be aware that even with the update problem, your plugin version works but you will not be able to obtain a fix for the problem, or even additions or improvements to the plugin because you are running a <b>Cancelled< version /b> or an <b>Obsolete</b> version.<br/><br/>To download the latest version, click the button « <b>'.TXT_BUTTON_8.'</b> » and to install it, click on the button « <b>Install now</b> ».');
    define('TABS_4_TEXT_15','<b>VERSION : </b>'.BLACKLISTED_IP_VERSION);
    define('TABS_4_TEXT_16','<b>LICENSE : </b> GPL2');
    define('TABS_4_TEXT_17','LICENSE :');
    define('TABS_4_TEXT_18','<abbr title="Version of the install & plugin you are using." class="initialism">VERSION : '.BLACKLISTED_IP_VERSION.'</abbr>');
    /* TABS = PRESENTATION (DOCUMENTATION) */
    define('TABS_1_TITLE_1','<b>MENU</b>');
    define('TABS_1_TITLE_2','WordPress plugin documentation '.BLACKLISTED_IP_NAME_2);
    define('TABS_1_MENU_1','Introduction & Prerequisites');
    define('TABS_1_MENU_2','Installation');
    define('TABS_1_MENU_3','Use');
    define('TABS_1_MENU_4','Caution');
    define('TABS_1_SUBTITLE_1','Introduction & Prerequisites');
    define('TABS_1_SUBTITLE_2','Installation');
    define('TABS_1_SUBTITLE_3','Use');
    define('TABS_1_SUBTITLE_4','Caution');
    define('TABS_1_TXT_1','Welcome to the documentation for the '.BLACKLISTED_IP_NAME_2.' plugin. This documentation is for users who want to use the plugin to blacklist users. Below, find the prerequisites of the plugin.<br><br>The plugin '.BLACKLISTED_IP_NAME_2.' allows you to manage a blacklist of IP addresses that are not allowed to access your WordPress site.');
    define('TABS_1_TXT_2','<ol><li>Download the plugin <code>Blacklisted IP</code> from the Github repository then download <code>blacklisted-ip</code> in the folder <code>/wp-content/plugins/</ code>.</li><li>Activate the plugin in your WordPress dashboard.</li><li>Access the plugin directly from the left side menu named <code>Blacklisted IP</code>. </li></ol>');
    define('TABS_1_TXT_3','Once the plugin is activated, you can access the <code>Blacklisted IP</code> page under "Settings" in your WordPress dashboard. This page allows you to add or remove IP addresses from the blacklist and view the list of banned IP addresses.');
    define('TABS_1_TXT_4','Using this plugin may block access to your site for banned IP addresses. Make sure not to ban your own IP address and back up the list of allowed IP addresses before adding addresses to the blacklist.');
    define('TABS_1_H_TABLE_1','PHP Required'); //Requires PHP
    define('TABS_1_H_TABLE_2','Requires at least'); //Requires at least
    define('TABS_1_H_TABLE_3','Tested up to'); //Tested up to
    define('TABS_1_H_TABLE_4','Stable release'); //Stable tag
    define('TABS_1_H_TABLE_5','Plug-in version'); //Version
    define('TABS_1_H_TABLE_6','License'); //License
    define('TABS_1_H_TABLE_7','License URL'); //URI License
    define('TABS_1_C_TABLE_1', PR_PHP_VERSION);
    define('TABS_1_C_TABLE_2', RL_WP_VERSION);
    define('TABS_1_C_TABLE_3', TUT_WP_VERSION);
    define('TABS_1_C_TABLE_4', ST_PLUGIN_VERSION);
    define('TABS_1_C_TABLE_5', BUILD_PLUGIN_VERSION);
    define('TABS_1_C_TABLE_6', LICENCE_PLUGIN_TYPE);
    define('TABS_1_BUTTON_1','Learn more ('.LICENCE_PLUGIN_TYPE.')');
    /* AUTRES ALERTE */
    define('PLUGIN_ALERT_PHP','<div class="notice notice-warning settings-error"><h3 class="text-warning">IMPORTANT ! - Your version of PHP is currently not supported!</h3><p>Your PHP version (<b>'.phpversion().'</b>) is currently not supported by the '.BLACKLISTED_IP_NAME_2.' plugin, at this time. The plugin supports up to PHP version '.PR_PHP_VERSION.'.<br></p></div>');
    define('PLUGIN_ALERT_UPDATE','<div class="notice notice-success"><h3>New update available!</h3><p>A new update is available, go to the <a href="admin.php?page=ip-blacklist&tab=tabs4">update page</a> to download and install it install or contact support to install.</p></div>');
}
/* AFFICHAGE D'UNE ERREUR LORS DE AUCUNE DETECTION DE LANGUE AUTOMATIQUE */
else
{
    /* MENU DU PLUGIN */
    define('TXT_MENU_TABS_1','Présentation');
    define('TXT_MENU_TABS_2','Bannir une IP');
    define('TXT_MENU_TABS_3','Journal des mises à jour');
    define('TXT_MENU_TABS_4','Mise à jour du plugin');
    define('TXT_MENU_TABS_5','À propos');
    /* BOUTONS */
    define('TXT_BUTTON_1','NOTRE SITE INTERNET');
    define('TXT_BUTTON_2','CONTACT SUPPORT');
    define('TXT_BUTTON_3','Télécharger la mise à jour');
    define('TXT_BUTTON_4','Voir le journal de mise à jour');
    define('TXT_BUTTON_5','<abbr title="Vous allez êtres rediriger vers Google Maps" class="initialism">Voir la localisation</abbr>');
    define('TXT_BUTTON_6','Ne plus bannir');
    define('TXT_BUTTON_7','Ajouter à la liste noire');
    define('TXT_BUTTON_8','Télécharger la dernière version');
    define('TXT_BUTTON_9','Installer maintenant');
    /* TEXTE DES TITRE DES PAGES */
    define('TITLE_PAGE_TABS_1','BIENVENUE SUR LE PLUGIN '.BLACKLISTED_IP_NAME.'.');
    define('TITLE_PAGE_TABS_2','Bannir / Débannir une <b>adresse IP</b>.');
    define('TITLE_PAGE_TABS_3','Journale des dernières mises à jours.');
    define('TITLE_PAGE_TABS_4','Mise à jour du plugin.');
    define('TITLE_PAGE_TABS_5','À propos, Licence & Informations sur l\'éditeur du plugin.');
    /* TABS = BANNIR UNE IP */
    define('TABS_2_ALERT_1','<div class="notice notice-warning settings-error is-dismissible"><p>L\'adresse IP a été ajoutée à la liste noire.</p></div>');
    define('TABS_2_ALERT_2','<div class="notice notice-success settings-error is-dismissible"><p>L\'adresse IP a été supprimée de la liste noire.</p></div>');
    define('TABS_2_TEXT_1','Veuillez saisir une adresse ip...');
    define('TABS_2_TEXT_2','Adresse IP');
    define('TABS_2_TEXT_3','Pays');
    define('TABS_2_TEXT_4','Ville');
    define('TABS_2_TEXT_5','Region');
    define('TABS_2_TEXT_6','Fuseaux horaires');
    define('TABS_2_TEXT_7','Localisation');
    define('TABS_2_TEXT_8','Action');
    /* TABS = MISE A JOUR */
    define('TABS_4_ALERT_1','Le plugin à détecter une nouvelle mise à jour. Merci de bien vouloir mettre à jour le plugin, car ça peut apporter des améliorations, des corrections ou encore des ajouts de nouvelles fonctionnalités.');
    define('TABS_4_ALERT_2_TITLE','INFORMATION SUR LA MISE À JOUR ET L\'INSTALLATION.');
    define('TABS_4_ALERT_2_CONTENT','Pour télécharger la mise à jour, vous avez juste à cliquez sur le bouton « <b>'.TXT_BUTTON_3.'</b> », et pour installer la mise à jour, veuillez vous rendre à la page « <b><a href="plugin-install.php?tab=upload" target="_parent">Extensions => Ajouter</a></b> » et à déplacer le fichier « <b><abbr title="Nom du fichier du plugin." class="initialism">blacklisted-ip.zip</abbr></b> » et cliquez sur le bouton « <b>Installer maintenant</b> ».');
    define('TABS_4_ALERT_3','Le plugin est actuellement à jour...');
    define('TABS_4_ALERT_4','Le système de mise à jour à détecter des problèmes lié avec votre version. Pour toutes sécurité, merci de bien vouloir télécharger la dernière version en cliquant sur le bouton ci-dessous...');
    define('TABS_4_TEXT_1','&nbsp;À UNE NOUVELLE MISE À JOUR DISPONIBLE...');
    define('TABS_4_TEXT_2','Version actuelle : ');
    define('TABS_4_TEXT_3','Nouvelles version : ');
    define('TABS_4_TEXT_4','ID de la mise à jour : ');
    define('TABS_4_TEXT_5','Mise à jour publié : ');
    define('TABS_4_TEXT_6','&nbsp;EST ACTUELLEMENT À JOUR...');
    define('TABS_4_TEXT_7','Version disponible : ');
    define('TABS_4_TEXT_8','ID de la dernière mise à jour : ');
    define('TABS_4_TEXT_9','Date de publication de la dernière mise à jour : ');
    define('TABS_4_TEXT_10','NOTE DE LA MISE À JOURS');
    define('TABS_4_TEXT_11','NOTE DE LA DERNIÈRE MISE À JOURS');
    define('TABS_4_TEXT_12','&nbsp;N\'ARRIVE PAS À DETECTER DE MISE À JOUR...');
    define('TABS_4_TEXT_13','<b style="color:red;">⚠ ATTENTION : </b>Le système de mise à jour n\'arrive pas à trouver de nouvelle mise à jour du plugin, car soient votre version à était modifier par une personne malveillante, et peut ainsi récupérer plusieurs données via notre code, ou, le plugin ne peut plus trouver de mise à jour, car les liens on était changer, ou soient, la version que vous avez est une version obsolète.');
    define('TABS_4_TEXT_14','Sachez que vous pouvez tout de même télécharger la dernière version via le bouton ci-dessous, en cas de problème.<br/><br/>Sachez que même avec le problème de mise à jour, votre version de plugin fonctionne mes vous ne pourrez pas obtenir de correctif aux problème, ou encore d\'ajouts ou d\'amélioration du plugin car vous exécuté une version <b>Annulée</b> ou une version <b>Obsolète</b>.<br/><br/>Pour télécharger le dernière version, cliquez sur le bouton « <b>'.TXT_BUTTON_8.'</b> » et pour l\'installer, cliquez sur le bouton « <b>Installer maintenant</b> ».');
    define('TABS_4_TEXT_15','<b>VERSION : </b>'.BLACKLISTED_IP_VERSION);
    define('TABS_4_TEXT_16','<b>LICENCE : </b> GPL2');
    define('TABS_4_TEXT_17','LICENCE :');
    define('TABS_4_TEXT_18','<abbr title="Version du plugin installer & que vous utilisez." class="initialism">VERSION : '.BLACKLISTED_IP_VERSION.'</abbr>');
    /* TABS = PRESENTATION (DOCUMENTATION) */
    define('TABS_1_TITLE_1','<b>MENU</b>');
    define('TABS_1_TITLE_2','Documentation du plugin WordPress '.BLACKLISTED_IP_NAME_2);
    define('TABS_1_MENU_1','Introduction & Prérequis');
    define('TABS_1_MENU_2','Installation');
    define('TABS_1_MENU_3','Utilisation');
    define('TABS_1_MENU_4','Avertissement');
    define('TABS_1_SUBTITLE_1','Introduction & Prérequis');
    define('TABS_1_SUBTITLE_2','Installation');
    define('TABS_1_SUBTITLE_3','Utilisation');
    define('TABS_1_SUBTITLE_4','Avertissement');
    define('TABS_1_TXT_1','Bienvenue dans la documentation du plugin '.BLACKLISTED_IP_NAME_2.'. Cette documentation est destinée aux utilisateurs qui souhaitent utiliser le plugin pour blacklister des utilisateurs. Ci-dessous, retrouvez ainsi les pré-requis du plugin.<br><br>Le plugin '.BLACKLISTED_IP_NAME_2.' vous permet de gérer une liste noire des adresses IP qui ne sont pas autorisées à accéder à votre site WordPress.');
    define('TABS_1_TXT_2','<ol><li>Téléchargez le plugin <code>Blacklisted IP</code> à partir du dépôt Github puis télécharger <code>blacklisted-ip</code> dans le dossier <code>/wp-content/plugins/</code>.</li><li>Activez le plugin dans votre tableau de bord WordPress.</li><li>Accéder directement au plugin depuis le menu latéral gauche qui porte le nom <code>Blacklisted IP</code>.</li></ol>');
    define('TABS_1_TXT_3','Une fois le plugin activé, vous pouvez accéder à la page <code>Blacklisted IP</code> en dessous de "Réglages" de votre tableau de bord WordPress. Cette page vous permet d\'ajouter ou de supprimer des adresses IP de la liste noire et de voir la liste des adresses IP bannies.');
    define('TABS_1_TXT_4','L\'utilisation de ce plugin peut bloquer l\'accès à votre site pour les adresses IP bannies. Assurez-vous de ne pas bannir votre propre adresse IP et de sauvegarder la liste des adresses IP autorisées avant d\'ajouter des adresses à la liste noire.');
    define('TABS_1_H_TABLE_1','PHP Requis'); //Requires PHP
    define('TABS_1_H_TABLE_2','Nécessite au moins'); //Requires at least
    define('TABS_1_H_TABLE_3','Testé jusqu\'à'); //Tested up to
    define('TABS_1_H_TABLE_4','Version stable'); //Stable tag
    define('TABS_1_H_TABLE_5','Version du plugin'); //Version
    define('TABS_1_H_TABLE_6','Licence'); //License
    define('TABS_1_H_TABLE_7','URL de la licence'); //URI License
    define('TABS_1_C_TABLE_1', PR_PHP_VERSION);
    define('TABS_1_C_TABLE_2', RL_WP_VERSION);
    define('TABS_1_C_TABLE_3', TUT_WP_VERSION);
    define('TABS_1_C_TABLE_4', ST_PLUGIN_VERSION);
    define('TABS_1_C_TABLE_5', BUILD_PLUGIN_VERSION);
    define('TABS_1_C_TABLE_6', LICENCE_PLUGIN_TYPE);
    define('TABS_1_BUTTON_1','En savoir + ('.LICENCE_PLUGIN_TYPE.')');
    /* AUTRES ALERTE */
    define('PLUGIN_ALERT_PHP','<div class="notice notice-warning settings-error"><h3 class="text-warning">IMPORTANT ! - Votre version de PHP n\'est actuellement pas prise en charge !</h3><p>Votre version PHP (<b>'.phpversion().'</b>) n\'est actuellement pas supporter par le plugin '.BLACKLISTED_IP_NAME_2.', pour le moment. Le plugin support jusqu\'à le version PHP '.PR_PHP_VERSION.'.<br></p></div>');
    define('PLUGIN_ALERT_UPDATE','<div class="notice notice-success"><h3>Nouvelle mise à jour disponible !</h3><p>Une nouvelle mise à jour est disponible, rendez-vous sur la <a href="admin.php?page=ip-blacklist&tab=tabs4">page de mise à jour</a> pour la télécharger et l\'installer ou contactez le support pour faire l\'installation.</p></div>');
}
?>