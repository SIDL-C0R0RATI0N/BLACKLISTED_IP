<?php
/**
 * +---------------------------------------------------------------------+
 * Blacklisted IP
 * 
 * @package   Blacklisted_IP
 * @author    sidlcorporation <developer@sidl-corporation.fr>
 * @license   GPL2
 * @link      https://www.sidl-corporation.fr/
 * @copyright 2020 - 2023 SIDL CORPORATION
 * 
 * Plugin Name:       Blacklisted IP
 * Plugin URI:        https://github.com/SIDL-C0R0RATI0N/BLACKLISTED_IP
 * Update URI:        https://github.com/SIDL-C0R0RATI0N/BLACKLISTED_IP
 * Description:       Le plugin Blacklisted IP, permet de bloquer les adresses IP dont vous souhaitez bloquer l'accès à votre site WordPress. Sachez que nous avons inclus différents fonctionnalités et que nous maintenons tout le temps le plugin à jour.
 * Version:           1.0.1
 * Requires at least: 4.0
 * Tested up to:      6.1.1
 * Requires PHP:      7.4
 * Stable tag:        1.0.1
 * Author:            SIDL CORPORATION
 * Author URI:        https://www.sidl-corporation.fr/
 * Text Domain:       blacklisted-ip
 * License:           GPL2
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.html
 * +---------------------------------------------------------------------+
*/
/* 
 * +---------------------------------------------------------------------+
 * CONFIGURATION DU PLUGIN
 * +---------------------------------------------------------------------+
*/
/* RECUPERATION DE LA VERSION WORDPRESS */
$wordpress_version = get_bloginfo('version');
/* IMPORTATION DES CONFIGURATIONS DU PLUGIN */
include_once('config/config_bkip.php'); // Module d'importation pour la configuration du plugin.
/* 
 * +---------------------------------------------------------------------+
 * BLACKLISTED IP : BLOCK
 * +---------------------------------------------------------------------+
*/
include('function/ip_blacklisted_block.php');
/* 
 * +---------------------------------------------------------------------+
 * AJOUTS DANS LE MENU ADMIN
 * +---------------------------------------------------------------------+
*/
include('function/ip_blacklist_admin_menu.php');
/* 
 * +---------------------------------------------------------------------+
 * SCRIPTS & STYLES
 * +---------------------------------------------------------------------+
*/
function ip_blacklist_enqueue_styles_and_scripts() 
{
    /* SCRIPT */
    wp_enqueue_script('toastr', plugin_dir_url(__FILE__) .'wp-assets/css/toastr.min.js', array('jquery'), '2.1.4', true);
    /* CSS */
    wp_enqueue_style('toastr-style', plugin_dir_url(__FILE__) .'wp-assets/js/toastr.min.css', array(), '2.1.4');
    wp_enqueue_style('ip-blacklist-style', plugin_dir_url(__FILE__) . 'wp-assets/css/ip-blacklist-style.css');
}

add_action('admin_notices', 'ip_blacklist_add_notification');
add_action('wp', 'ip_blacklist_block');
add_action('admin_enqueue_scripts', 'ip_blacklist_enqueue_styles_and_scripts');
add_action('admin_menu', 'ip_blacklist_admin_menu');

function ip_blacklist_add_notification() {
    if (isset($_GET['ip_added'])) {
        $ip = $_GET['ip_added'];
        echo '<div class="notice notice-success is-dismissible"><p>IP Address '.$ip.' has been added to the blacklist.</p></div>';
    }
    if (isset($_GET['ip_removed'])) {
        $ip = $_GET['ip_removed'];
        echo '<div class="notice notice-success is-dismissible"><p>IP Address '.$ip.' has been removed from the blacklist.</p></div>';
    }
}

function ip_blacklist_page() {
    
    // Display blacklist form and list of blacklisted IPs
    $ip_list = get_option('ip_blacklist', array());
    $active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'tabs1'; 
    ?>
    <header style="display: flex; justify-content: space-between; align-items: center; padding: 20px;">
        <?php if (phpversion() >= '7.4') : ?>
            <?= PLUGIN_ALERT_PHP;?>
        <?php endif; ?>
        <?php if(version_compare(BLACKLISTED_IP_VERSION, BLACKLISTED_IP_NEWS_VERSION, '<')) : ?>
            <?= PLUGIN_ALERT_UPDATE;?>
        <?php endif; ?>
        <div style="display: flex; align-items: center;">
            <img src="<?php echo plugin_dir_url( __FILE__ ) . 'wp-assets/img/logo_2.png'; ?>" alt="<?php echo esc_html( get_admin_page_title() ); ?>" style="max-height: 50px; margin-right: 10px;">
            <h1 style="margin: 0;"><?php echo esc_html( get_admin_page_title() ); ?></h1>
        </div>
        <div style="display: flex; align-items: left;">
            <p style="padding:5px;margin: 5px"><?= TABS_4_TEXT_18;?> | <?= ADMIN_YOUR_IP;?></p>
            <a class="button button-primary" href="https://www.sidl-corporation.fr/" target="_blank" rel="noopener noreferrer" style="margin: 5px"><?= TXT_BUTTON_1;?></a>
            <a class="button button-secondary" href="mailto:contact@sidl-corporation.fr" target="_blank" rel="noopener noreferrer" style="margin: 5px"><?= TXT_BUTTON_2;?></a>
        </div>
    </header>
    <h2 class="nav-tab-wrapper">
        <a href="?page=ip-blacklist&tab=tabs1" class="nav-tab <?php echo $active_tab == 'tabs1' ? 'nav-tab-active' : ''; ?>"><?= TXT_MENU_TABS_1;?></a>
        <a href="?page=ip-blacklist&tab=tabs2" class="nav-tab <?php echo $active_tab == 'tabs2' ? 'nav-tab-active' : ''; ?>"><?= TXT_MENU_TABS_2;?></a>
        <a href="?page=ip-blacklist&tab=tabs3" class="nav-tab <?php echo $active_tab == 'tabs3' ? 'nav-tab-active' : ''; ?>"><?= TXT_MENU_TABS_3;?></a>
        <a href="?page=ip-blacklist&tab=tabs4" class="nav-tab <?php echo $active_tab == 'tabs4' ? 'nav-tab-active' : ''; ?>"><?= TXT_MENU_TABS_4;?></a>
        <a href="?page=ip-blacklist&tab=tabs5" class="nav-tab <?php echo $active_tab == 'tabs5' ? 'nav-tab-active' : ''; ?>"><?= TXT_MENU_TABS_5;?></a>
    </h2>
    <div class="wrap">
        <?php if( $active_tab == 'tabs1' ) { ?>
            <h2><?= TITLE_PAGE_TABS_1;?></h2><hr>
            <div class="bkip">
                <?php include('view/doc/doc.php') ?>
            </div>
            <!--
            <div class="bkip">
                <div class="bkip__info">
                    <img src="<?php echo plugin_dir_url( __FILE__ ).'wp-assets/img/logo.png'; ?>" alt="Logo de <?php echo esc_html( get_admin_page_title() ); ?>" class="bkip__logo">
                    <div class="bkip__details">
                    <h2 class="bkip__name"><?php echo esc_html( get_admin_page_title() ); ?></h2>
                    <p class="bkip__version">Version : <?= BLACKLISTED_IP_VERSION;?></p>
                    <p class="bkip__author">Éditeur : <?= BLACKLISTED_IP_AUTHOR;?></p>
                    </div>
                </div>
                <div class="bkip__actions">
                    <button class="bkip__button button button-primary" style="margin-right: 5px;">Activer</button>
                    <button class="bkip__button button button-secondary">Désactiver</button>
                </div>
            </div>-->
        <?php } elseif( $active_tab == 'tabs2' ) { ?>
            <h2><?= TITLE_PAGE_TABS_2;?></h2>
            <div style="margin-left: 0px;margin-top: 5px;margin-right: 5px;margin-bottom: 5px;">
                <?php 
                // Add IP to blacklist
                if (isset($_POST['ip'])) {
                    $ip = sanitize_text_field($_POST['ip']);
                    $ip_list = get_option('ip_blacklist', array());
                    
                    if (!in_array($ip, array_keys($ip_list))) {
                        $details = json_decode(file_get_contents(BLACKLISTED_IP_URL_IPINFO_PART_1."{$ip}".BLACKLISTED_IP_URL_IPINFO_PART_2));
                        $ip_list[$ip] = $details;
                        update_option('ip_blacklist', $ip_list);
                        echo ''.TABS_2_ALERT_1.'';
                    }
                }

                // Remove IP from blacklist
                if (isset($_POST['remove_ip'])) {
                    $ip = sanitize_text_field($_POST['remove_ip']);
                    $ip_list = get_option('ip_blacklist', array());
                    echo ''.TABS_2_ALERT_2.'';
                    
                    if (in_array($ip, array_keys($ip_list))) {
                        unset($ip_list[$ip]);
                        update_option('ip_blacklist', $ip_list);
                    }
                }
                ?>
                <form method="post">
                    <input type="text" id="ip-address" name="ip" placeholder="<?= TABS_2_TEXT_1;?>" required/>
                    <input class="button button-primary" type="submit" value="<?= TXT_BUTTON_7;?>" />
                </form>
            </div>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><b><?= TABS_2_TEXT_2;?></b></th>
                        <th><b><?= TABS_2_TEXT_3;?></b></th>
                        <th><b><?= TABS_2_TEXT_4;?></b></th>
                        <th><b><?= TABS_2_TEXT_5;?></b></th>
                        <th><b><?= TABS_2_TEXT_6;?></b></th>
                        <th><b><?= TABS_2_TEXT_7;?></b></th>
                        <th><b><?= TABS_2_TEXT_8;?></b></th>
                    </tr>
                </thead>
                <?php foreach ($ip_list as $ip => $details) {?>
                <tbody>
                    <tr>
                        <td><?php echo $ip; ?></td>
                        <td><?php echo $details->country;?></td>
                        <td><?php echo $details->city; ?></td>
                        <td><?php echo $details->region; ?></td>
                        <td><?php echo $details->timezone; ?></td>
                        <td><a class="button button-secondary" href="https://www.google.com/search?q=<?php echo $details->loc; ?>" target="_blank" rel="noopener noreferrer"><?= TXT_BUTTON_5;?></a></td>
                        <td>
                            <form method="post">
                                <input type="hidden" name="remove_ip" value="<?php echo $ip; ?>" />
                                <input class="button button-primary" type="submit" value="<?= TXT_BUTTON_6;?>" />
                            </form>
                        </td>
                    </tr>
                </tbody>
                <?php } ?>
            </table>
        <?php } elseif( $active_tab == 'tabs3' ) { ?>
            <h2><?= TITLE_PAGE_TABS_3;?></h2>
            <?php
                include_once('wp-assets/markdown/Parsedown.php');
                $Parsedown = new Parsedown();
                $changelog_file = file_get_contents('https://dl.sidl-corporation.fr/dl/blacklisted-ip/CHANGELOG.md');
                echo '<div class="log_update">'.$Parsedown->text($changelog_file).'</div>';
            ?>
        <?php } elseif( $active_tab == 'tabs4' ) { ?>
            <h2><?= TITLE_PAGE_TABS_4;?></h2>
            <hr>
            <?php 
                /* RECUPERATION DE LA VERSION ACTUELLE */
                $_current_version = 'v'.get_plugin_data(__FILE__)['Version'];
                /* CONFIGURATION POUR LES FONCTIONS GITHUB */
                $repositories = 'SIDL-C0R0RATI0N/BLACKLISTED_IP';
                $response_github = wp_remote_get("https://api.github.com/repos/{$repositories}/releases/latest");
                /* RECUPERATION DE LA DERNIERE VERSION SUR GITHUB */
                $latest_version = json_decode(wp_remote_retrieve_body($response_github), true)['tag_name'];
                $url_download = json_decode(wp_remote_retrieve_body($response_github), true)['zipball_url'];
                $changelog_note_body = json_decode(wp_remote_retrieve_body($response_github), true)['body'];
                $id_update = json_decode(wp_remote_retrieve_body($response_github), true)['node_id'];
                $last_version = json_decode(wp_remote_retrieve_body($response_github), true)['name'];
                $published_date = json_decode(wp_remote_retrieve_body($response_github), true)['published_at'];
                $published_timestamp = strtotime($published_date);
                $published_update = date("d/m/Y - H:i", $published_timestamp);
                if(version_compare($_current_version,$latest_version, '<'))
                {
                    // Si une mise à jour est disponible.
            ?>
            <div>
                <div style="display: flex; align-items: center;">
                    <img src="<?php echo plugin_dir_url( __FILE__ ).'wp-assets/img/update/yes_update.png'; ?>" style="max-height: 50px; margin-right: 10px;">
                    <h1 style="margin: 0;color:steelblue;"><b><?php echo esc_html(get_admin_page_title()).TABS_4_TEXT_1; ?></b></h1>
                </div>
                <p>
                    <b><?= TABS_4_TEXT_2;?></b><?= BLACKLISTED_IP_VERSION;?><br/>
                    <b><?= TABS_4_TEXT_3;?></b><?= $last_version;?><br/>
                    <b><?= TABS_4_TEXT_4;?></b><?= $id_update;?><br/>
                    <b><?= TABS_4_TEXT_5;?></b><?= $published_update;?><br/>
                </p>
                <div class="update-notice">
                    <div class="notice notice-warning settings-error">
                        <p><?= TABS_4_ALERT_1;?></p>
                    </div>
                    <a href="https://github.com/<?php echo $repositories;?>/archive/<?php echo $latest_version;?>.zip" target="_blank" class="button button-primary"><?= TXT_BUTTON_3;?></a>
                    <a href="https://github.com/<?php echo $repositories;?>/blob/main/CHANGELOG.md" target="_blank" class="button button-secondary"><?= TXT_BUTTON_4;?></a>
                    <div class="notice notice-danger settings-error is-dismissible">
                        <h3><b><?= TABS_4_ALERT_2_TITLE;?></b></h3>
                        <p><?= TABS_4_ALERT_2_CONTENT;?></p>
                    </div>
                </div>
                <hr>
                <div class="update-notice">
                    <h3><?= TABS_4_TEXT_10;?></h3>
                    <?php
                        include_once('wp-assets/markdown/Parsedown.php');
                        $Parsedown = new Parsedown();
                        echo '<div class="log_update">'.$Parsedown->text($changelog_note_body).'</div>';
                    ?>
                </div>
            </div>
            <?php
                }
                elseif(version_compare($_current_version, $latest_version, '='))
                {
                    // Si vous avez une version identique
            ?>
            <div>
                <div style="display: flex; align-items: center;">
                    <img src="<?php echo plugin_dir_url( __FILE__ ).'wp-assets/img/update/no_update.png'; ?>" style="max-height: 50px; margin-right: 10px;">
                    <h1 style="margin: 0;color:seagreen;"><b><?php echo esc_html(get_admin_page_title()).TABS_4_TEXT_6; ?></b></h1>
                </div>
                <p>
                    <b><?= TABS_4_TEXT_2;?></b><?= BLACKLISTED_IP_VERSION;?><br/>
                    <b><?= TABS_4_TEXT_7;?></b><?= $last_version;?><br/>
                    <b><?= TABS_4_TEXT_8;?></b><?= $id_update;?><br/>
                    <b><?= TABS_4_TEXT_9;?></b><?= $published_update;?><br/>
                </p>
                <div class="update-notice">
                    <div class="notice notice-success is-dismissible">
                        <p><?= TABS_4_ALERT_3;?></p>
                    </div>
                    <a href="https://github.com/<?php echo $repositories;?>/blob/main/CHANGELOG.md" target="_blank" class="button button-secondary"><?= TXT_BUTTON_4;?></a>
                </div>
                <hr>
                <div class="update-notice">
                    <h3><?= TABS_4_TEXT_11;?></h3>
                    <?php
                        include_once('wp-assets/markdown/Parsedown.php');
                        $Parsedown = new Parsedown();
                        echo '<div class="log_update">'.$Parsedown->text($changelog_note_body).'</div>';
                    ?>
                </div>
            </div>
            <?php
                }
                else
                {
                    // Si un problème de recherche de mise à jour surgis
            ?>
            <div>
                <div style="display: flex; align-items: center;">
                    <img src="<?php echo plugin_dir_url( __FILE__ ).'wp-assets/img/update/error_update.png'; ?>" style="max-height: 50px; margin-right: 10px;">
                    <h1 style="margin: 0;color:brown"><b><?php echo esc_html(get_admin_page_title()).TABS_4_TEXT_12; ?></b></h1>
                </div>
                <p>
                    <h4><?= TABS_4_TEXT_13;?></h4>
                    <?= TABS_4_TEXT_14;?>
                </p>
                <div class="update-notice">
                    <a href="https://github.com/<?php echo $repositories;?>/archive/<?php echo $latest_version;?>.zip" target="_blank" class="button button-primary"><?= TXT_BUTTON_8;?></a>
                    <a href="plugin-install.php?tab=upload" target="_parent" class="button button-secondary"><?= TXT_BUTTON_9;?></a>
                    <div class="notice notice-danger is-dismissible">
                        <p>
                            <?= TABS_4_ALERT_4;?><br><br>
                            <a href="https://github.com/<?php echo $repositories;?>/archive/<?php echo $latest_version;?>.zip" target="_blank" class="button button-primary"><?= TXT_BUTTON_8;?></a>
                            <a href="plugin-install.php?tab=upload" target="_parent" class="button button-secondary"><?= TXT_BUTTON_9;?></a>
                        </p>
                    </div>
                </div>
            </div>
            <?php
                }
            ?>
        <?php } elseif( $active_tab == 'tabs5' ) { ?>
            <h2><?= TITLE_PAGE_TABS_5;?></h2><hr>
            <div class="plugin-about">
                <div class="plugin-logo">
                    <img src="<?php echo plugin_dir_url( __FILE__ ).'wp-assets/img/logo_2.png'; ?>" alt="<?php echo esc_html( get_admin_page_title() ); ?>">
                </div>
                <div class="plugin-info">
                    <h2 class="plugin-name"><?php echo esc_html( get_admin_page_title() ); ?></h2>
                    <p class="plugin-version"><?= TABS_4_TEXT_15;?></p>
                    <p class="plugin-license"><?= TABS_4_TEXT_16;?></p>
                </div>
                <div>
                    <hr>
                    <h2><?= TABS_4_TEXT_17;?></h2>
                    <?php
                        include_once('wp-assets/markdown/Parsedown.php');
                        $Parsedown = new Parsedown();
                        $changelog_file = file_get_contents('https://dl.sidl-corporation.fr/dl/blacklisted-ip/LICENSE.md');
                        echo '<div class="log_update">'.$Parsedown->text($changelog_file).'</div>';
                    ?>
                </div>
            </div>
            <hr>
            <header style="display: flex; justify-content: space-between; align-items: center; padding: 20px;">
                <div style="display: flex; align-items: center;">
                    <img src="<?php echo plugin_dir_url( __FILE__ ) . 'wp-assets/img/author/icone.png'; ?>" alt="SIDL CORPORATION" style="max-height: 50px; margin-right: 10px;">
                    <h1 style="margin: 0;">SIDL CORPORATION</h1>
                </div>
                <div style="display: flex; align-items: left;">
                    <a class="button button-primary" href="https://www.sidl-corporation.fr/" target="_blank" rel="noopener noreferrer" style="margin: 5px"><?= TXT_BUTTON_1;?></a>
                </div>
            </header>
        <?php } ?>
    </div>
<?php
}
?>