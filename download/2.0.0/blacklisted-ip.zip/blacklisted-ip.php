<?php
/**
 * +---------------------------------------------------------------------+
 * Blacklisted IP
 * 
 * @package   Blacklisted_IP
 * @author    sidlcorporation <developer@sidl-corporation.fr>
 * @license   GPL2
 * @link      https://www.sidl-corporation.fr/
 * @copyright 2020 - 2023 SIDL CORPORATION
 * 
 * Plugin Name:       Blacklisted IP
 * Plugin URI:        https://github.com/SIDL-C0R0RATI0N/BLACKLISTED_IP
 * Update URI:        https://github.com/SIDL-C0R0RATI0N/BLACKLISTED_IP
 * Description:       The Blacklisted IP plugin allows you to block the IP addresses you want to block access to your WordPress site. Know that we have included different features and that we keep the plugin updated all the time.
 * Version:           2.0.0
 * Requires at least: 6.0
 * Tested up to:      6.1.1
 * Requires PHP:      8.x
 * Stable tag:        2.0.0
 * Author:            SIDL CORPORATION
 * Author URI:        https://www.sidl-corporation.fr/
 * Text Domain:       blacklisted-ip
 * License:           GPL2
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.html
 * +---------------------------------------------------------------------+
*/
if(!defined('ABSPATH')) 
{
	exit;
}
/* 
 * +---------------------------------------------------------------------+
 * CONFIGURATION DU PLUGIN
 * +---------------------------------------------------------------------+
*/
/* RECUPERATION DE LA VERSION WORDPRESS */
$wordpress_version = get_bloginfo('version');
/* IMPORTATION DES CONFIGURATIONS DU PLUGIN */
include_once('config/config_bkip.php'); // Module d'importation pour la configuration du plugin.
/* CREATION DE LA PAGE */
// Fonction pour créer la page d'erreur personnalisée lors de l'activation du plugin
function create_custom_error_page() 
{
    $page_title = 'You have been blacklisted.';
    $page_content = '<h1>Your IP address has been blacklisted !</h1><p>We\'re sorry, but your IP address was blacklisted. For any questions relating to your banishment from the site, please contact the company that blacklisted you.</p>';
    $page = array(
        'post_title'    => $page_title,
        'post_content'  => $page_content,
        'post_status'   => 'publish',
        'post_type'     => 'page',
        'post_name'     => 'error-1020'
    );
    $page_id = wp_insert_post($page);
  
    // Enregistrer le numéro de la page d'erreur personnalisée dans les options du plugin
    update_option( 'custom_error_page_id', $page_id);
}
  
// Ajouter l'action pour exécuter la fonction de création de la page lors de l'activation du plugin
register_activation_hook( __FILE__, 'create_custom_error_page' );
  
// Fonction pour vérifier si une adresse IP est en liste noire
function ip_blacklist_block() 
{
    $ip_list = get_option('ip_blacklist', array());
    $ip_address = $_SERVER['REMOTE_ADDR'];
    if(in_array($ip_address, $ip_list)) {
        return true;
    }
    return false;
}
  
// Action pour rediriger les utilisateurs en liste noire vers la page d'erreur personnalisée
add_action( 'template_redirect', 'custom_error_page_redirect' );
function custom_error_page_redirect() 
{
    if(ip_blacklist_block()) 
    {
        $page_id = get_option('custom_error_page_id');
        $error_page_url = get_permalink($page_id);
        wp_redirect($error_page_url);
        exit;
    }
}
// Désactiver l'affichage des éléments du thème pour la page d'erreur
add_filter('template_include', 'custom_error_page_template', 99);
function custom_error_page_template($template) 
{
    if(is_page('error-1020')) 
    {
        $custom_error_template = dirname( __FILE__ ) . '/error.php';
        if(file_exists($custom_error_template)) 
        {
            return $custom_error_template;
        }
    }
    return $template;
}
/* 
 * +---------------------------------------------------------------------+
 * AJOUTS DANS LE MENU ADMIN
 * +---------------------------------------------------------------------+
*/
function ip_blacklist_admin_menu() {
    // Add menu page
    add_menu_page(
        ''.BLACKLISTED_IP_NAME.'', // Le nom de la page dans le menu
        ''.BLACKLISTED_IP_NAME.'', // Le nom de la page
        'manage_options', // Le niveau de permission nécessaire pour voir la page
        'ip-blacklist', // Le slug de la page
        'ip_blacklist_page', // La fonction qui affiche la page
        'dashicons-podio' // L'icône à utiliser
    );
}
/* 
 * +---------------------------------------------------------------------+
 * SCRIPTS & STYLES
 * +---------------------------------------------------------------------+
*/
function ip_blacklist_enqueue_styles_and_scripts() 
{
    /* SCRIPT */
    wp_enqueue_script('toastr', plugin_dir_url(__FILE__) .'wp-assets/css/toastr.min.js', array('jquery'), '2.1.4', true);
    /* CSS */
    wp_enqueue_style('toastr-style', plugin_dir_url(__FILE__) .'wp-assets/js/toastr.min.css', array(), '2.1.4');
    wp_enqueue_style('ip-blacklist-style', plugin_dir_url(__FILE__) . 'wp-assets/css/ip-blacklist-style.css');
}

add_action('admin_notices', 'ip_blacklist_add_notification');
add_action('wp', 'ip_blacklist_block');
add_action('admin_enqueue_scripts', 'ip_blacklist_enqueue_styles_and_scripts');
add_action('admin_menu', 'ip_blacklist_admin_menu');

function ip_blacklist_add_notification() {
    if (isset($_GET['ip_added'])) {
        $ip = $_GET['ip_added'];
        echo '<div class="notice notice-success is-dismissible"><p>IP Address '.$ip.' has been added to the blacklist.</p></div>';
    }
    if (isset($_GET['ip_removed'])) {
        $ip = $_GET['ip_removed'];
        echo '<div class="notice notice-success is-dismissible"><p>IP Address '.$ip.' has been removed from the blacklist.</p></div>';
    }
}

function ip_blacklist_page() {
    
    // Display blacklist form and list of blacklisted IPs
    $ip_list = get_option('ip_blacklist', array());
    $active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'tabs1'; 
    ?> 
    <header style="display: flex; justify-content: space-between; align-items: center; padding: 20px;">
        <?php if (phpversion() >= ''.PR_PHP_VERSION.'') : ?>
            <?= PLUGIN_ALERT_PHP;?>
        <?php endif; ?>
        <?php if(version_compare(BLACKLISTED_IP_VERSION, BLACKLISTED_IP_NEWS_VERSION, '<')) : ?>
            <?= PLUGIN_ALERT_UPDATE;?>
        <?php endif; ?>
        <div style="display: flex; align-items: center;">
            <img src="<?php echo plugin_dir_url( __FILE__ ) . 'wp-assets/img/logo_2.png'; ?>" alt="<?php echo esc_html( get_admin_page_title() ); ?>" style="max-height: 50px; margin-right: 10px;">
            <h1 style="margin: 0;"><?php echo esc_html( get_admin_page_title() ); ?></h1>
        </div>
        <div style="display: flex; align-items: left;">
            <p style="padding:5px;margin: 5px"><?= TABS_4_TEXT_18;?> | <?= ADMIN_YOUR_IP;?></p>
            <a class="button button-primary" href="https://www.sidl-corporation.fr/" target="_blank" rel="noopener noreferrer" style="margin: 5px"><?= TXT_BUTTON_1;?></a>
            <a class="button button-secondary" href="mailto:contact@sidl-corporation.fr" target="_blank" rel="noopener noreferrer" style="margin: 5px"><?= TXT_BUTTON_2;?></a>
        </div>
    </header>
    <h2 class="nav-tab-wrapper">
        <a href="?page=ip-blacklist&tab=tabs1" class="nav-tab <?php echo $active_tab == 'tabs1' ? 'nav-tab-active' : ''; ?>"><?= TXT_MENU_TABS_1;?></a>
        <a href="?page=ip-blacklist&tab=tabs2" class="nav-tab <?php echo $active_tab == 'tabs2' ? 'nav-tab-active' : ''; ?>"><?= TXT_MENU_TABS_2;?></a>
        <a href="?page=ip-blacklist&tab=tabs3" class="nav-tab <?php echo $active_tab == 'tabs3' ? 'nav-tab-active' : ''; ?>"><?= TXT_MENU_TABS_3;?></a>
        <a href="?page=ip-blacklist&tab=tabs4" class="nav-tab <?php echo $active_tab == 'tabs4' ? 'nav-tab-active' : ''; ?>"><?= TXT_MENU_TABS_4;?></a>
        <a href="?page=ip-blacklist&tab=tabs5" class="nav-tab <?php echo $active_tab == 'tabs5' ? 'nav-tab-active' : ''; ?>"><?= TXT_MENU_TABS_5;?></a>
    </h2>
    <div class="wrap">
        <?php if( $active_tab == 'tabs1' ) { ?>
            <h2><?= TITLE_PAGE_TABS_1;?></h2><hr>
            <div class="bkip">
                <?php include('view/doc/doc.php') ?>
            </div>
        <?php } elseif( $active_tab == 'tabs2' ) { ?>
            <h2><?= TITLE_PAGE_TABS_2;?></h2>
            <div style="margin-left: 0px;margin-top: 5px;margin-right: 5px;margin-bottom: 5px;">
                <?php 
                // Add IP to blacklist
                if (isset($_POST['ip'])) {
                    $ip = sanitize_text_field($_POST['ip']);
                    $ip_list = get_option('ip_blacklist', array());
                    
                    if (!in_array($ip, array_keys($ip_list))) {
                        $details = json_decode(file_get_contents(BLACKLISTED_IP_URL_IPINFO_PART_1."{$ip}".BLACKLISTED_IP_URL_IPINFO_PART_2));
                        $ip_list[$ip] = $details;
                        update_option('ip_blacklist', $ip_list);
                        echo ''.TABS_2_ALERT_1.'';
                    }
                }

                // Remove IP from blacklist
                if (isset($_POST['remove_ip'])) {
                    $ip = sanitize_text_field($_POST['remove_ip']);
                    $ip_list = get_option('ip_blacklist', array());
                    echo ''.TABS_2_ALERT_2.'';
                    
                    if (in_array($ip, array_keys($ip_list))) {
                        unset($ip_list[$ip]);
                        update_option('ip_blacklist', $ip_list);
                    }
                }
                ?>
                <form method="post">
                    <input type="text" id="ip-address" name="ip" placeholder="<?= TABS_2_TEXT_1;?>" required/>
                    <input class="button button-primary" type="submit" value="<?= TXT_BUTTON_7;?>" />
                </form>
            </div>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><b><?= TABS_2_TEXT_2;?></b></th>
                        <th><b><?= TABS_2_TEXT_3;?></b></th>
                        <th><b><?= TABS_2_TEXT_4;?></b></th>
                        <th><b><?= TABS_2_TEXT_5;?></b></th>
                        <th><b><?= TABS_2_TEXT_6;?></b></th>
                        <th><b><?= TABS_2_TEXT_7;?></b></th>
                        <th><b><?= TABS_2_TEXT_8;?></b></th>
                    </tr>
                </thead>
                <?php foreach ($ip_list as $ip => $details) {?>
                <tbody>
                    <tr>
                        <td><?php echo $ip; ?></td>
                        <td><?php echo $details->country;?></td>
                        <td><?php echo $details->city; ?></td>
                        <td><?php echo $details->region; ?></td>
                        <td><?php echo $details->timezone; ?></td>
                        <td><a class="button button-secondary" href="https://www.google.com/search?q=<?php echo $details->loc; ?>" target="_blank" rel="noopener noreferrer"><?= TXT_BUTTON_5;?></a></td>
                        <td>
                            <form method="post">
                                <input type="hidden" name="remove_ip" value="<?php echo $ip; ?>" />
                                <input class="button button-primary" type="submit" value="<?= TXT_BUTTON_6;?>" />
                            </form>
                        </td>
                    </tr>
                </tbody>
                <?php } ?>
            </table>
            <br>
            <?php
            ?>
        <?php } elseif( $active_tab == 'tabs3' ) { ?>
            <h2><?= TITLE_PAGE_TABS_3;?></h2>
            <?php
                include_once('wp-assets/markdown/Parsedown.php');
                $Parsedown = new Parsedown();
                $changelog_file = file_get_contents('https://dl.sidl-corporation.fr/dl/blacklisted-ip/CHANGELOG.md');
                echo '<div class="log_update">'.$Parsedown->text($changelog_file).'</div>';
            ?>
        <?php } elseif( $active_tab == 'tabs4' ) { ?>
            <h2><?= TITLE_PAGE_TABS_4;?></h2>
            <hr>
            <?php 
                /* RECUPERATION DE LA VERSION ACTUELLE */
                $_current_version = 'v'.get_plugin_data(__FILE__)['Version'];
                /* CONFIGURATION POUR LES FONCTIONS GITHUB */
                $repositories = 'SIDL-C0R0RATI0N/BLACKLISTED_IP';
                $response_github = wp_remote_get("https://api.github.com/repos/{$repositories}/releases/latest");
                /* RECUPERATION DE LA DERNIERE VERSION SUR GITHUB */
                $latest_version = json_decode(wp_remote_retrieve_body($response_github), true)['tag_name'];
                $url_download = json_decode(wp_remote_retrieve_body($response_github), true)['zipball_url'];
                $changelog_note_body = json_decode(wp_remote_retrieve_body($response_github), true)['body'];
                $id_update = json_decode(wp_remote_retrieve_body($response_github), true)['node_id'];
                $last_version = json_decode(wp_remote_retrieve_body($response_github), true)['name'];
                $published_date = json_decode(wp_remote_retrieve_body($response_github), true)['published_at'];
                $published_timestamp = strtotime($published_date);
                $published_update = date("d/m/Y - H:i", $published_timestamp);
                if(version_compare($_current_version,$latest_version, '<'))
                {
                    // Si une mise à jour est disponible.
            ?>
            <div>
                <div style="display: flex; align-items: center;">
                    <img src="<?php echo plugin_dir_url( __FILE__ ).'wp-assets/img/update/yes_update.png'; ?>" style="max-height: 50px; margin-right: 10px;">
                    <h1 style="margin: 0;color:steelblue;"><b><?php echo esc_html(get_admin_page_title()).TABS_4_TEXT_1; ?></b></h1>
                </div>
                <p>
                    <b><?= TABS_4_TEXT_2;?></b><?= BLACKLISTED_IP_VERSION;?><br/>
                    <b><?= TABS_4_TEXT_3;?></b><?= $last_version;?><br/>
                    <b><?= TABS_4_TEXT_4;?></b><?= $id_update;?><br/>
                    <b><?= TABS_4_TEXT_5;?></b><?= $published_update;?><br/>
                </p>
                <div class="update-notice">
                    <div class="notice notice-warning settings-error">
                        <p><?= TABS_4_ALERT_1;?></p>
                    </div>
                    <a href="https://github.com/<?php echo $repositories;?>/archive/<?php echo $latest_version;?>.zip" target="_blank" class="button button-primary"><?= TXT_BUTTON_3;?></a>
                    <a href="https://github.com/<?php echo $repositories;?>/blob/main/CHANGELOG.md" target="_blank" class="button button-secondary"><?= TXT_BUTTON_4;?></a>
                    <div class="notice notice-danger settings-error is-dismissible">
                        <h3><b><?= TABS_4_ALERT_2_TITLE;?></b></h3>
                        <p><?= TABS_4_ALERT_2_CONTENT;?></p>
                    </div>
                </div>
                <hr>
                <div class="update-notice">
                    <h3><?= TABS_4_TEXT_10;?></h3>
                    <?php
                        include_once('wp-assets/markdown/Parsedown.php');
                        $Parsedown = new Parsedown();
                        echo '<div class="log_update">'.$Parsedown->text($changelog_note_body).'</div>';
                    ?>
                </div>
            </div>
            <?php
                }
                elseif(version_compare($_current_version, $latest_version, '='))
                {
                    // Si vous avez une version identique
            ?>
            <!-- Version 2
            <div class="bkip_updater">
                <div class="bkip_update_header">
                    <div class="bkip_update_icon">
                        <img src="<?php echo plugin_dir_url( __FILE__ ).'wp-assets/img/update/no_update.png'; ?>" alt="Update icon">
                    </div>
                    <div class="bkip_update_title">
                        <h2>New Update Available</h2>
                        <p>Blacklisted IP plugin</p>
                    </div>
                </div>
                <div class="bkip_update_body">
                    <div class="bkip_update_version">
                        <div class="bkip_update_version_title">Current Version:</div>
                        <div class="bkip_update_version_number">1.0.0</div>
                    </div>
                    <div class="bkip_update_version">
                        <div class="bkip_update_version_title">New Version:</div>
                        <div class="bkip_update_version_number">2.0.0</div>
                    </div>
                    <div class="bkip_update_id">
                        <div class="bkip_update_id_title">Update ID:</div>
                        <div class="bkip_update_id_number">#123456789</div>
                    </div>
                    <div class="bkip_update_date">
                        <div class="bkip_update_date_title">Release Date:</div>
                        <div class="bkip_update_date_number">March 31, 2023</div>
                    </div>
                    <div class="bkip_update_buttons">
                        <a href="#" class="bkip_update_button">Update Now</a>
                        <a href="#" class="bkip_update_button">Remind Me Later</a>
                    </div>
                    <hr style="border:none;border-top:1px solid #E5E5E5;margin:20px 0;">
                    <div class="bkip_update_notes">
                        <div class="bkip_update_notes_title">Release Notes:</div>
                            <ul class="bkip_update_notes_list">
                                <li>Improved performance</li>
                                <li>Added new features</li>
                                <li>Fixed bugs</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            -->
            <div>
                <div style="display: flex; align-items: center;">
                    <img src="<?php echo plugin_dir_url( __FILE__ ).'wp-assets/img/update/no_update.png'; ?>" style="max-height: 50px; margin-right: 10px;">
                    <h1 style="margin: 0;color:seagreen;"><b><?php echo esc_html(get_admin_page_title()).TABS_4_TEXT_6; ?></b></h1>
                </div>
                <p>
                    <b><?= TABS_4_TEXT_2;?></b><?= BLACKLISTED_IP_VERSION;?><br/>
                    <b><?= TABS_4_TEXT_7;?></b><?= $last_version;?><br/>
                    <b><?= TABS_4_TEXT_8;?></b><?= $id_update;?><br/>
                    <b><?= TABS_4_TEXT_9;?></b><?= $published_update;?><br/>
                </p>
                <div class="update-notice">
                    <div class="notice notice-success is-dismissible">
                        <p><?= TABS_4_ALERT_3;?></p>
                    </div>
                    <a href="https://github.com/<?php echo $repositories;?>/blob/main/CHANGELOG.md" target="_blank" class="button button-secondary"><?= TXT_BUTTON_4;?></a>
                </div>
                <hr>
                <div class="update-notice">
                    <h3><?= TABS_4_TEXT_11;?></h3>
                    <?php
                        include_once('wp-assets/markdown/Parsedown.php');
                        $Parsedown = new Parsedown();
                        echo '<div class="log_update">'.$Parsedown->text($changelog_note_body).'</div>';
                    ?>
                </div>
            </div>
            <?php
                }
                else
                {
                    // Si un problème de recherche de mise à jour surgis
            ?>
            <div>
                <div style="display: flex; align-items: center;">
                    <img src="<?php echo plugin_dir_url( __FILE__ ).'wp-assets/img/update/error_update.png'; ?>" style="max-height: 50px; margin-right: 10px;">
                    <h1 style="margin: 0;color:brown"><b><?php echo esc_html(get_admin_page_title()).TABS_4_TEXT_12; ?></b></h1>
                </div>
                <p>
                    <h4><?= TABS_4_TEXT_13;?></h4>
                    <?= TABS_4_TEXT_14;?>
                </p>
                <div class="update-notice">
                    <a href="https://github.com/<?php echo $repositories;?>/archive/<?php echo $latest_version;?>.zip" target="_blank" class="button button-primary"><?= TXT_BUTTON_8;?></a>
                    <a href="plugin-install.php?tab=upload" target="_parent" class="button button-secondary"><?= TXT_BUTTON_9;?></a>
                    <div class="notice notice-danger is-dismissible">
                        <p>
                            <?= TABS_4_ALERT_4;?><br><br>
                            <a href="https://github.com/<?php echo $repositories;?>/archive/<?php echo $latest_version;?>.zip" target="_blank" class="button button-primary"><?= TXT_BUTTON_8;?></a>
                            <a href="plugin-install.php?tab=upload" target="_parent" class="button button-secondary"><?= TXT_BUTTON_9;?></a>
                        </p>
                    </div>
                </div>
            </div>
            <?php
                }
            ?>
        <?php } elseif( $active_tab == 'tabs5' ) { ?>
            <h2><?= TITLE_PAGE_TABS_5;?></h2><hr>
            <div class="plugin-about">
                <div class="plugin-logo">
                    <img src="<?php echo plugin_dir_url( __FILE__ ).'wp-assets/img/logo_2.png'; ?>" alt="<?php echo esc_html( get_admin_page_title() ); ?>">
                </div>
                <div class="plugin-info">
                    <h2 class="plugin-name"><?php echo esc_html( get_admin_page_title() ); ?></h2>
                    <p class="plugin-version"><?= TABS_4_TEXT_15;?></p>
                    <p class="plugin-license"><?= TABS_4_TEXT_16;?></p>
                </div>
                <div>
                    <hr>
                    <h2><?= TABS_4_TEXT_17;?></h2>
                    <?php
                        include_once('wp-assets/markdown/Parsedown.php');
                        $Parsedown = new Parsedown();
                        $changelog_file = file_get_contents('https://dl.sidl-corporation.fr/dl/blacklisted-ip/LICENSE.md');
                        echo '<div class="log_update">'.$Parsedown->text($changelog_file).'</div>';
                    ?>
                </div>
            </div>
            <hr>
            <header style="display: flex; justify-content: space-between; align-items: center; padding: 20px;">
                <div style="display: flex; align-items: center;">
                    <img src="<?php echo plugin_dir_url( __FILE__ ) . 'wp-assets/img/author/icone.png'; ?>" alt="SIDL CORPORATION" style="max-height: 50px; margin-right: 10px;">
                    <h1 style="margin: 0;">SIDL CORPORATION</h1>
                </div>
                <div style="display: flex; align-items: left;">
                    <a class="button button-primary" href="https://www.sidl-corporation.fr/" target="_blank" rel="noopener noreferrer" style="margin: 5px"><?= TXT_BUTTON_1;?></a>
                </div>
            </header>
        <?php } ?>
    </div>
<?php
}
?>