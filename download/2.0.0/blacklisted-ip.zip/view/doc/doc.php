<div class="bkipdoc">
    <?php
        // Définir le menu avec un tableau de sections
        $menu = array(
            ''.TABS_1_MENU_1.'' => "intro_and_prerequis",
            ''.TABS_1_MENU_2.'' => "installation",
            ''.TABS_1_MENU_3.'' => "utilisation",
            ''.TABS_1_MENU_4.'' => "avertissement",
            ''.TABS_1_MENU_5.'' => "news" 
        );
        // Afficher le menu
        echo "<div class='bkipdoc-menu'>";
        echo '<h2>'.TABS_1_TITLE_1.'</h2>';
        echo "<ul>";
        foreach ($menu as $section => $id) {
          echo "<li><a class='button button-primary' style='width: 100%;' href='#$id'>$section</a></li>";
        }
        echo "</ul>";
        echo "</div>";
    ?>
    <div class="bkipdoc-content log_update_2">
        <h1><?= TABS_1_TITLE_2;?></h1>
        <div id="intro_and_prerequis" class="bkipdoc-section log_update_3">
            <h2><?= TABS_1_SUBTITLE_1;?></h2>
            <p>
                <?= TABS_1_TXT_1;?>
            </p>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><b><?= TABS_1_H_TABLE_1;?></b></th>
                        <th><b><?= TABS_1_H_TABLE_2;?></b></th>
                        <th><b><?= TABS_1_H_TABLE_3;?></b></th>
                        <th><b><?= TABS_1_H_TABLE_4;?></b></th>
                        <th><b><?= TABS_1_H_TABLE_5;?></b></th>
                        <th><b><?= TABS_1_H_TABLE_6;?></b></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?= TABS_1_C_TABLE_1;?></td>
                        <td><?= TABS_1_C_TABLE_2;?></td>
                        <td><?= TABS_1_C_TABLE_3;?></td>
                        <td><?= TABS_1_C_TABLE_4;?></td>
                        <td><?= TABS_1_C_TABLE_5;?></td>
                        <td>
                            <a class="button button-primary" href="http://www.gnu.org/licenses/gpl-2.0.html" target="_blank" type="button"><?= TABS_1_BUTTON_1;?></a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div id="installation" class="bkipdoc-section log_update_3">
            <h2><?= TABS_1_SUBTITLE_2;?></h2>
            <p><?= TABS_1_TXT_2;?></p>
        </div>
        <div id="utilisation" class="bkipdoc-section log_update_3">
            <h2><?= TABS_1_SUBTITLE_3;?></h2>
            <p><?= TABS_1_TXT_3;?></p>
        </div>
        <div id="avertissement" class="bkipdoc-section log_update_3">
            <h2><?= TABS_1_SUBTITLE_4;?></h2>
            <p><?= TABS_1_TXT_4;?></p>
        </div>
        <div id="news" class="bkipdoc-section log_update_3">
            <h2><?= TABS_1_SUBTITLE_5;?></h2>
            <p><?= TABS_1_TXT_5;?></p>
        </div>
    </div>
</div>