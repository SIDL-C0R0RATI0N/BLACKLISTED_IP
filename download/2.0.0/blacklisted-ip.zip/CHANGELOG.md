### VERSION [2.0.0] | 24/03/2023
#### Mise à jour majeur.
* [FIXED] Nous avons mise à jour la version PHP du Plugin, dont nous utilisons désormais la version 8.x.
* [FIXED] Nous avons corriger un problème de sécurité.
* [ADD] Ajouts de la page dédier aux visiteurs en liste noire (Disponible dans vos Pages, à ne pas supprimer).
* [ADD] Ajouts d'une nouvelles section dans la documentation du plugin.
* [UPDATE] Mise à jour de sécurités revue, ainsi que la performence du plugin.
* [UPDATE] Plus de 50 lignes de code on était mise à jour. 

***

### VERSION [1.0.1] | 21/03/2023
#### Mise à jour de correction & d'ajouts.
* [ADD] Traduction du plugin automatique selon la langue de votre navigateur web.
* [ADD] Page de présentation officiel en première page avec la documentation du plugin.
* [FIXED] Plus de 25 problèmes on était corriger.
* [FIXED] Système de mise à jour plus performant et sans plus aucun problème.
* [UPDATE] Le plugin et découper en plusieurs partie, dont plus performant que la première version.
* [UPDATE] Le logo du plugin seras un nouveau logo.

***

### VERSION [1.0.0] | 20/03/2023
#### Version initiale (Publique)
* [FIXED] Cette version (`1.0.0 - PUBLIC`) vient d'être finalisé. Elle est maintenant disponible au publique.

***

### VERSION [0.0.1] | 19/03/2023
#### Initiale version
* [ADD] The version `0.0.1` is a version under development.