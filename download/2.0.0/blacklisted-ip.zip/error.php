
    <!DOCTYPE html>
    <html>
        <head>
            <meta charset="UTF-8">
            <meta name="generator" content="SIDL CORPORATION">
            <meta name="author" content="SIDL CORPORATION">
            <meta name="copyright" content="SIDL CORPORATION"/>
            <meta name="Publisher" content="SIDL CORPORATION"/>
            <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
            <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
            <meta http-equiv="X-UA-Compatible" content="IE=edge" /> 
            <meta http-equiv="X-UA-Compatible" content="IE=10" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="shortcut icon" href="https://img.icons8.com/3d-fluency/94/null/cancel.png" type="image/x-icon">
            <style>
            body {
                background-color: #000;
                background: url(https://www.networksolutions.com/blog/accelerate/email/three-tactics-to-avoid-being-ip-blacklisted-as-a-business/_jcr_content/root/section/image.coreimg.jpeg/1615519532961/ip-address.jpeg) no-repeat center center fixed;
                background-size: cover;
                font-family: Helvetica, Arial, sans-serif;
                font-size: 10pt;
                padding-top: 50px;
                text-align: left
            }

            a {
                color: rgb(255, 255, 255);
                text-decoration: none
            }

            a:hover {
                text-decoration: underline
            }

            .container {
                margin: auto;
                max-width: 540px;
                min-width: 200px
            }

            .box hr {
                display: block;
                border: none;
                border-bottom: 1px dashed #ccc
            }

            .box {
                background-color: #fbfbfb46;
                -webkit-backdrop-filter: saturate(100%) blur(30px);
                backdrop-filter: saturate(100%) blur(30px);
                border: 1px solid #AAA;
                border-bottom: 1px solid rgba(218, 218, 218, .489);
                border-radius: 15px;
                color: rgb(255, 255, 255);
                padding: 20px
            }

            .box h1,
            .box h2 {
                display: block;
                text-align: center
            }

            .box h1 {
                color: rgb(255, 0, 0);
                font-weight: 400;
                font-size: 45px;
                padding: 0;
                margin: 0;
                margin-top: 10px;
                line-height: 50px
            }

            .box h2 {
                color: rgb(255, 180, 180);
                font-weight: 400;
                font-size: 10px
            }

            .box p {
                color: rgb(255, 255, 255);
                display: block;
                margin-bottom: 10px
            }

            .box ul li {
                margin-bottom: 7px
            }

            .copyright {
                display: block;
                text-align: center;
                color: rgb(173, 173, 173);
                font-weight: 400;
                margin-top: 20px
            }
            </style>
            <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
            <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
            <title>You have been blacklisted.</title>
        </head>
        <body>
            <div class="container">
                <div class="box">
                    <h1>Your IP address <b><?php '('.$_SERVER['REMOTE_ADDR'].')';?></b> has been blacklisted !</h1><p>We're sorry, but your IP address was blacklisted. For any questions relating to your banishment from the site, please contact the company that blacklisted you.</p>
                </div>
            </div>
            <div class="copyright">
                &copy; <script>document.write(new Date().getFullYear())</script> Blacklisted IP - By SIDL CORPORATION - All Rights Reserved.
            </div>
        </body>
    </html>
    