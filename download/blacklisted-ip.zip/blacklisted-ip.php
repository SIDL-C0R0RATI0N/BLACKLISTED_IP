<?php
/**
 * +---------------------------------------------------------------------+
 * Blacklisted IP
 * 
 * @package   Blacklisted_IP
 * @author    sidlcorporation <developer@sidl-corporation.fr>
 * @license   GPL2
 * @link      https://www.sidl-corporation.fr/
 * @copyright 2020 - 2023 SIDL CORPORATION
 * 
 * Plugin Name:       Blacklisted IP
 * Plugin URI:        https://github.com/SIDL-C0R0RATI0N/BLACKLISTED_IP
 * Description:       Cette nouvelle version (v5.0.0) de Blacklisted IP, n'utilise plus la fonction CloudFlare, mes utilise maintenant les fonctionnalités interne.
 * Version:           1.0.0
 * Requires at least: 4.0
 * Tested up to:      6.1.1
 * Requires PHP:      7.4
 * Stable tag:        1.0.0
 * Author:            SIDL CORPORATION
 * Author URI:        https://www.sidl-corporation.fr/
 * Text Domain:       blacklisted-ip
 * License:           GPL2
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.html
 * +---------------------------------------------------------------------+
*/

/* 
 * +---------------------------------------------------------------------+
 * RECUPERATION DE LA VERSION WORDPRESS
 * +---------------------------------------------------------------------+
*/
$wordpress_version = get_bloginfo('version');

/* 
 * +---------------------------------------------------------------------+
 * CONFIGURATION DU PLUGIN
 * +---------------------------------------------------------------------+
*/
define('BLACKLISTED_IP_NAME','BLACKLISTED IP');
define('BLACKLISTED_IP_VERSION','1.0.0');
define('BLACKLISTED_IP_VERSION_TYPE','STABLE');
define('BLACKLISTED_IP_SLUG', 'blacklisted-ip');
define('BLACKLISTED_IP_PLUGIN_DOMAIN','blacklisted-ip');
define('BLACKLISTED_IP_PLUGIN_PACKAGE_NAME','ip_blacklist');
define('BLACKLISTED_IP_URL_IPINFO_PART_1', 'http://ipinfo.io/');
define('BLACKLISTED_IP_URL_IPINFO_PART_2', '/json');
define('BLACKLISTED_IP_GITHUB_USERNAME', 'SIDL-C0R0RATI0N');
define('BLACKLISTED_IP_GITHUB_REPO', 'BLACKLISTED_IP');
define('BLACKLISTED_IP_GITHUB_API_URL', 'https://api.github.com/repos/'.BLACKLISTED_IP_GITHUB_USERNAME.'/'.BLACKLISTED_IP_GITHUB_REPO);
define('BLACKLISTED_IP_URL_CHANGELOG','https://github.com/'.BLACKLISTED_IP_GITHUB_USERNAME.'/'.BLACKLISTED_IP_GITHUB_REPO.'/blob/main/CHANGELOG.md#version-4001--22102022');
/* VERSION WORDPRESS */
define('BLACKLISTED_IP_WP_VERSION', $wordpress_version);
define('BLACKLISTED_IP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('BLACKLISTED_IP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('BLACKLISTED_IP_PLUGIN_BASENAME', plugin_basename(__FILE__));
/* AUTRES CONFIGURATION */
define('BLACKLISTED_IP_SUPPORT_LINK','');
define('BLACKLISTED_IP_RELEASES_LINK','');
define('BLACKLISTED_IP','Bienvenue sur la nouvelles version (<i>'.BLACKLISTED_IP_VERSION.'</i>) du plugin <b>'.BLACKLISTED_IP_NAME.'</b>. Dans cette nouvelle version, nous avons apporter des nouveautés, dont nous avons supprimer la fonctionnalité avec <b>CloudFlare</b>. Dont vous pouvez l\'utiliser à votre guise.');
define('BLACKLISTED_IP_DESCRIP','Bienvenue sur la nouvelle version du Plugin <b>'.BLACKLISTED_IP_NAME.'</b>.<br/> Dans cette nouvelle version, nous avons faite quelques changement. N\'hésitez pas à voir notre changelog pour la version <a href="'.BLACKLISTED_IP_URL_CHANGELOG.'" target="_blank">'.BLACKLISTED_IP_VERSION.'</a>.');
define('BTN_TXT_HOME','Présentation');
define('BTN_TXT_BLACKLISTED','Bannir une adresse IP');
define('BTN_TXT_CHANGELOG','Journale des mises à jours');
define('BTN_TXT_UPDATE','Mises à jours du plugin');
define('BTN_TXT_ABOUTS','À propos.');
/* 
 * +---------------------------------------------------------------------+
 * BLACKLISTED IP : BLOCK
 * +---------------------------------------------------------------------+
*/
function ip_blacklist_block() 
{
    $ip_list = get_option('ip_blacklist', array());
    $ip_address = $_SERVER['REMOTE_ADDR'];
    if (in_array($ip_address, $ip_list)) {
        wp_die('Votre adresse IP a été bloquée.');
    }
}

// Add admin menu and blacklist form
function ip_blacklist_admin_menu() {
    // Add menu page
    add_menu_page('Blacklisted IP', 'Blacklisted IP', 'manage_options', 'ip-blacklist', 'ip_blacklist_page');
}
function ip_blacklist_enqueue_scripts() {
    wp_enqueue_script('toastr', plugin_dir_url(__FILE__) .'wp-assets/css/toastr.min.js', array('jquery'), '2.1.4', true);
    wp_enqueue_style('toastr-style', plugin_dir_url(__FILE__) .'wp-assets/js/toastr.min.css', array(), '2.1.4');
}
// Enqueue plugin stylesheet
function ip_blacklist_enqueue_styles() {
    wp_enqueue_style('ip-blacklist-style', plugin_dir_url(__FILE__) . 'wp-assets/css/ip-blacklist-style.css');
}
function ip_blacklist_add_notification() {
    if (isset($_GET['ip_added'])) {
        $ip = $_GET['ip_added'];
        echo '<div class="notice notice-success is-dismissible"><p>IP Address '.$ip.' has been added to the blacklist.</p></div>';
    }
    if (isset($_GET['ip_removed'])) {
        $ip = $_GET['ip_removed'];
        echo '<div class="notice notice-success is-dismissible"><p>IP Address '.$ip.' has been removed from the blacklist.</p></div>';
    }
}
add_action('admin_notices', 'ip_blacklist_add_notification');

add_action('wp', 'ip_blacklist_block');
add_action('admin_enqueue_scripts', 'ip_blacklist_enqueue_styles');
add_action('admin_enqueue_scripts', 'ip_blacklist_enqueue_scripts');
add_action('admin_menu', 'ip_blacklist_admin_menu');

function ip_blacklist_page() {
    
    // Display blacklist form and list of blacklisted IPs
    $ip_list = get_option('ip_blacklist', array());
    $active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'tabs2'; 
    ?>
    <header style="display: flex; justify-content: space-between; align-items: center; padding: 20px;">
        <div style="display: flex; align-items: center;">
            <img src="<?php echo plugin_dir_url( __FILE__ ) . 'wp-assets/img/logo.png'; ?>" alt="<?php echo esc_html( get_admin_page_title() ); ?>" style="max-height: 50px; margin-right: 10px;">
            <h1 style="margin: 0;"><?php echo esc_html( get_admin_page_title() ); ?></h1>
        </div>
        <div style="display: flex; align-items: left;">
            <p style="padding:5px;margin: 5px">VERSION : <?= BLACKLISTED_IP_VERSION;?></p>
            <a class="button button-primary" href="https://www.sidl-corporation.fr/" target="_blank" rel="noopener noreferrer" style="margin: 5px">NOTRE SITE OFFICIEL</a>
            <a class="button button-secondary" href="mailto:contact@sidl-corporation.fr" target="_blank" rel="noopener noreferrer" style="margin: 5px">NOUS CONTACTER</a>
        </div>
    </header>
    <h2 class="nav-tab-wrapper">
        <!--
        <a href="?page=ip-blacklist&tab=tabs1" class="nav-tab <?php echo $active_tab == 'tabs1' ? 'nav-tab-active' : ''; ?>"><?= BTN_TXT_HOME;?></a>
        -->
        <a href="?page=ip-blacklist&tab=tabs2" class="nav-tab <?php echo $active_tab == 'tabs2' ? 'nav-tab-active' : ''; ?>"><?= BTN_TXT_BLACKLISTED;?></a>
        <a href="?page=ip-blacklist&tab=tabs3" class="nav-tab <?php echo $active_tab == 'tabs3' ? 'nav-tab-active' : ''; ?>"><?= BTN_TXT_CHANGELOG;?></a>
        <a href="?page=ip-blacklist&tab=tabs4" class="nav-tab <?php echo $active_tab == 'tabs4' ? 'nav-tab-active' : ''; ?>"><?= BTN_TXT_UPDATE;?></a>
        <a href="?page=ip-blacklist&tab=tabs5" class="nav-tab <?php echo $active_tab == 'tabs5' ? 'nav-tab-active' : ''; ?>"><?= BTN_TXT_ABOUTS;?></a>
    </h2>
    <div class="wrap">
    <?php if( $active_tab == 'tabs1' ) { ?>
            <h2><?= BTN_TXT_HOME;?></h2>
            <p>This is the content for Tab 1.</p>
        <?php } elseif( $active_tab == 'tabs2' ) { ?>
            <h2><?= BTN_TXT_BLACKLISTED;?></h2>
            <div style="margin-left: 0px;margin-top: 5px;margin-right: 5px;margin-bottom: 5px;">
                <?php 
                // Add IP to blacklist
                if (isset($_POST['ip'])) {
                    $ip = sanitize_text_field($_POST['ip']);
                    $ip_list = get_option('ip_blacklist', array());
                    
                    if (!in_array($ip, array_keys($ip_list))) {
                        $details = json_decode(file_get_contents(BLACKLISTED_IP_URL_IPINFO_PART_1."{$ip}".BLACKLISTED_IP_URL_IPINFO_PART_2));
                        $ip_list[$ip] = $details;
                        update_option('ip_blacklist', $ip_list);
                        echo '<div class="notice notice-warning settings-error is-dismissible"><p>L\'adresse IP <b>'.$ip.'</b> a été ajoutée à la liste noire.</p></div>';
                    }
                }

                // Remove IP from blacklist
                if (isset($_POST['remove_ip'])) {
                    $ip = sanitize_text_field($_POST['remove_ip']);
                    $ip_list = get_option('ip_blacklist', array());
                    echo '<div class="notice notice-success settings-error is-dismissible"><p>L\'adresse IP <b>'.$ip.'</b> a été supprimée de la liste noire.</p></div>';
                    
                    if (in_array($ip, array_keys($ip_list))) {
                        unset($ip_list[$ip]);
                        update_option('ip_blacklist', $ip_list);
                    }
                }
                ?>
                <form method="post">
                    <input type="text" id="ip-address" name="ip" placeholder="Entrez une adresse IP" required/>
                    <input class="button button-primary" type="submit" value="Ajouter à la liste noire" />
                </form>
            </div>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><b>Adresse IP</b></th>
                        <th><b>Pays</b></th>
                        <th><b>Ville</b></th>
                        <th><b>Region</b></th>
                        <th><b>Fuseaux horaires</b></th>
                        <th><b>Localisation</b></th>
                        <th><b>Action</b></th>
                    </tr>
                </thead>
                <?php foreach ($ip_list as $ip => $details) {?>
                <tbody>
                    <tr>
                        <td><?php echo $ip; ?></td>
                        <td><?php echo $details->country;?></td>
                        <td><?php echo $details->city; ?></td>
                        <td><?php echo $details->region; ?></td>
                        <td><?php echo $details->timezone; ?></td>
                        <td><a class="button button-secondary" href="https://www.google.com/search?q=<?php echo $details->loc; ?>" target="_blank" rel="noopener noreferrer">Voir la localisation</a></td>
                        <td>
                            <form method="post">
                                <input type="hidden" name="remove_ip" value="<?php echo $ip; ?>" />
                                <input class="button button-primary" type="submit" value="Supprimer" />
                            </form>
                        </td>
                    </tr>
                </tbody>
                <?php } ?>
            </table>
        <?php } elseif( $active_tab == 'tabs3' ) { ?>
            <h2><?= BTN_TXT_CHANGELOG;?></h2>
            <?php
                include_once('wp-assets/markdown/Parsedown.php');
                $Parsedown = new Parsedown();
                $changelog_file = file_get_contents('https://dl.sidl-corporation.fr/dl/blacklisted-ip/CHANGELOG.md');
                echo '<div class="log_update">'.$Parsedown->text($changelog_file).'</div>';
            ?>
        <?php } elseif( $active_tab == 'tabs4' ) { ?>
            <h2><?= BTN_TXT_UPDATE;?></h2>
            <hr>
            <?php 
                /* RECUPERATION DE LA VERSION ACTUELLE */
                $_current_version = 'v'.get_plugin_data(__FILE__)['Version'];
                /* CONFIGURATION POUR LES FONCTIONS GITHUB */
                $repositories = 'SIDL-C0R0RATI0N/BLACKLISTED_IP';
                $response_github = wp_remote_get("https://api.github.com/repos/{$repositories}/releases/latest");
                /* RECUPERATION DE LA DERNIERE VERSION SUR GITHUB */
                $latest_version = json_decode(wp_remote_retrieve_body($response_github), true)['tag_name'];
                $url_download = json_decode(wp_remote_retrieve_body($response_github), true)['zipball_url'];
                $changelog_note_body = json_decode(wp_remote_retrieve_body($response_github), true)['body'];
                $id_update = json_decode(wp_remote_retrieve_body($response_github), true)['node_id'];
                $last_version = json_decode(wp_remote_retrieve_body($response_github), true)['name'];
                $published_date = json_decode(wp_remote_retrieve_body($response_github), true)['published_at'];
                $published_timestamp = strtotime($published_date);
                $published_update = date("d/m/Y - H:i", $published_timestamp);
                if(version_compare($_current_version,$latest_version, '<'))
                {
                    // Si une mise à jour est disponible.
            ?>
            <div>
                <div style="display: flex; align-items: center;">
                    <img src="<?php echo plugin_dir_url( __FILE__ ).'wp-assets/img/update/yes_update.png'; ?>" style="max-height: 50px; margin-right: 10px;">
                    <h1 style="margin: 0;"><?php echo esc_html(get_admin_page_title()).'&nbsp;à une nouvelle mise à jour disponible...'; ?></h1>
                </div>
                <p>
                    <b>Version actuelle : </b><?= BLACKLISTED_IP_VERSION;?><br/>
                    <b>Nouvelles version : </b><?= $last_version;?><br/>
                    <b>ID de la mise à jour : </b><?= $id_update;?><br/>
                    <b>Mise à jour publié : </b><?= $published_update;?><br/>
                </p>
                <div class="update-notice">
                    <div class="notice notice-warning settings-error">
                        <p>Nous souhaitons annoncez que une nouvelle mise à jour (<b>version : <?= $last_version;?></b>) du plugin est maintenant disponible en téléchargement. Merci de bien vouloir mettre à jour le plugin, car la mise à jour pourrais apporté des corrections à des bugs.</p>
                    </div>
                    <a href="https://github.com/<?php echo $repositories;?>/archive/<?php echo $latest_version;?>.zip" target="_blank" class="button button-primary">Télécharger la nouvelle mise à jour</a>
                    <a href="https://github.com/<?php echo $repositories;?>/blob/main/CHANGELOG.md" target="_blank" class="button button-secondary">Voir le changelog</a>
                </div>
                <hr>
                <div class="update-notice">
                    <h3>Note de la mise à jour :</h3>
                    <?php
                        include_once('wp-assets/markdown/Parsedown.php');
                        $Parsedown = new Parsedown();
                        echo '<div class="log_update">'.$Parsedown->text($changelog_note_body).'</div>';
                    ?>
                </div>
            </div>
            <?php
                }
                elseif(version_compare($_current_version, $latest_version, '='))
                {
                    // Si vous avez une version identique
            ?>
            <div>
                <div style="display: flex; align-items: center;">
                    <img src="<?php echo plugin_dir_url( __FILE__ ).'wp-assets/img/update/no_update.png'; ?>" style="max-height: 50px; margin-right: 10px;">
                    <h1 style="margin: 0;"><?php echo esc_html(get_admin_page_title()).'&nbsp;est actuellement à jour...'; ?></h1>
                </div>
                <p>
                    <b>Version actuelle : </b><?= BLACKLISTED_IP_VERSION;?><br/>
                    <b>Version installé : </b><?= $last_version;?><br/>
                    <b>ID de la dernière mise à jour : </b><?= $id_update;?><br/>
                    <b>Date de publication de la dernière mise à jour : </b><?= $published_update;?><br/>
                </p>
                <div class="update-notice">
                    <div class="notice notice-success is-dismissible">
                        <p>Vous avez actuellement la dernière version de disponible.</p>
                    </div>
                    <a href="https://github.com/<?php echo $repositories;?>/blob/main/CHANGELOG.md" target="_blank" class="button button-secondary">Voir le changelog</a>
                </div>
                <hr>
                <div class="update-notice">
                    <h3>Note de la dernière mise à jour (version : <?= $last_version;?>) :</h3>
                    <?php
                        include_once('wp-assets/markdown/Parsedown.php');
                        $Parsedown = new Parsedown();
                        echo '<div class="log_update">'.$Parsedown->text($changelog_note_body).'</div>';
                    ?>
                </div>
            </div>
            <?php
                }
                else
                {
                    // Si un problème de recherche de mise à jour surgis
            ?>
            <div>
                <div style="display: flex; align-items: center;">
                    <img src="<?php echo plugin_dir_url( __FILE__ ).'wp-assets/img/update/error_update.png'; ?>" style="max-height: 50px; margin-right: 10px;">
                    <h1 style="margin: 0;"><?php echo esc_html(get_admin_page_title()).'&nbsp;à des problèmes de recherche de mise à jour...'; ?></h1>
                </div>
                <p>
                    <b>Version actuelle : </b>NaN/NaN<br/>
                    <b>Version installé : </b>NaN/NaN<br/>
                    <b>ID de la dernière mise à jour : </b>NaN/NaN<br/>
                    <b>Date de publication de la dernière mise à jour : </b>NaN/NaN<br/>
                </p>
                <div class="update-notice">
                    <div class="notice notice-danger is-dismissible">
                        <p>Le plugin à un problème avec les recherche de mise à jour. Merci de désactivé et réactivé le plugin.</p>
                    </div>
                </div>
            </div>
            <?php
                }
            ?>
        <?php } elseif( $active_tab == 'tabs5' ) { ?>
            <h2><?= BTN_TXT_ABOUTS;?></h2>
            <div class="plugin-about">
                <div class="plugin-logo">
                    <img src="<?php echo plugin_dir_url( __FILE__ ).'wp-assets/img/logo.png'; ?>" alt="Logo du plugin">
                </div>
                <div class="plugin-info">
                    <h2 class="plugin-name"><?php echo esc_html( get_admin_page_title() ); ?></h2>
                    <p class="plugin-version">Version <?= BLACKLISTED_IP_VERSION;?></p>
                    <p class="plugin-license">Licence : GPL2</p>
                </div>
                <div>
                    <hr>
                    <h2><?php echo 'License';?></h2>
                    <?php
                        include_once('wp-assets/markdown/Parsedown.php');
                        $Parsedown = new Parsedown();
                        $changelog_file = file_get_contents('https://dl.sidl-corporation.fr/dl/blacklisted-ip/LICENSE.md');
                        echo '<div class="log_update">'.$Parsedown->text($changelog_file).'</div>';
                    ?>
                </div>
            </div>
            <hr>
            <header style="display: flex; justify-content: space-between; align-items: center; padding: 20px;">
                <div style="display: flex; align-items: center;">
                    <img src="<?php echo plugin_dir_url( __FILE__ ) . 'wp-assets/img/author/icone.png'; ?>" alt="SIDL CORPORATION" style="max-height: 50px; margin-right: 10px;">
                    <h1 style="margin: 0;">SIDL CORPORATION</h1>
                </div>
                <div style="display: flex; align-items: left;">
                    <a class="button button-primary" href="https://www.sidl-corporation.fr/" target="_blank" rel="noopener noreferrer" style="margin: 5px">NOTRE SITE OFFICIEL</a>
                </div>
            </header>
        <?php } ?>
    </div>
<?php
}
?>